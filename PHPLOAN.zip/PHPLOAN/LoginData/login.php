<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars(trim($_POST['username']));
    $password = htmlspecialchars(trim($_POST['password']));

    $file_path = 'users.json';
    

    if (!file_exists($file_path)) {
        echo json_encode(['error' => 'Users database not found.']);
        exit;
    }

    $json_data = file_get_contents($file_path);
    $data = json_decode($json_data, true);

    if (!isset($data['users']) || !is_array($data['users'])) {
        echo json_encode(['error' => 'Invalid user data structure.']);
        exit;
    }

     $authenticated = false;

    foreach ($data['users'] as &$user) {
        if ($user['username'] === $username && password_verify($password, $user['password'])) {
            session_regenerate_id(true);

            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'] ?? 'user';
            $_SESSION['profile_picture'] = $user['profile_picture'] ?? 'uploads/default-profile.png';

            $user['last_active'] = time();
            file_put_contents($file_path, json_encode($data, JSON_PRETTY_PRINT));

            $authenticated = true;
            break;
        }
    }

    if ($authenticated) {
        $role = $_SESSION['role'];

        // Redirect based on role
        if ($role === 'admin') {
            $redirect = '../dashboard/admin.php';
        } elseif ($role === 'officer') {
            $redirect = '../dashboard/admindashboard.php';
        } else {
            $redirect = '../dashboard/index.php';
        }

        echo json_encode([
            'success' => "Logged in as $role. Redirecting...",
            'redirect' => $redirect,
            'role' => $role
        ]);
    } else {
        echo json_encode(['error' => 'Invalid username or password.']);
    }
} else {
    header("Location: ../Login/login.php");
    exit;
}
?>