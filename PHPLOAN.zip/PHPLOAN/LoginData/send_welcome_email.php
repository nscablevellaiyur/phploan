<?php include '../header.php'; ?>

<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Make sure Composer's autoloader is available

function sendWelcomeEmail($to, $username) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';     // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'suriyamass9442@gmail.com'; // SMTP username
        $mail->Password = 'qiuzdeijpixojstu';            // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use TLS or SSL
        $mail->Port = 587; // Usually 587 for TLS, 465 for SSL

        // Recipients
        $mail->setFrom('no-reply@yourdomain.com', 'Loan System');
        $mail->addAddress($to, $username);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Welcome to Our Loan System';
        $mail->Body = "
            <html>
            <head><title>Welcome</title></head>
            <body style='font-family: Arial, sans-serif; color: #333;'>
                <h2>Hello $username,</h2>
                <p>Thank you for registering with our loan management system.</p>
                <p>You can now log in and apply for loans from your dashboard.</p>
                <p><strong>Login:</strong> <a href='http://yourdomain.com/index.php'>Click here</a></p>
                <br>
                <p>Regards,<br>Loan System Team</p>
            </body>
            </html>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer error: " . $mail->ErrorInfo);
        return false;
    }
}
?>

<?php include '../footer.php'; ?>