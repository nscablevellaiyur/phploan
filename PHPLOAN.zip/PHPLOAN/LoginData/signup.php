<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/phpmailer/src/Exception.php';
require '../phpmailer/phpmailer/src/PHPMailer.php';
require '../phpmailer/phpmailer/src/SMTP.php';

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $response = [];

    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $username = htmlspecialchars(trim($_POST['username']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));
    $confirm_password = htmlspecialchars(trim($_POST['confirm_password']));
    $role = htmlspecialchars(trim($_POST['role'] ?? 'user'));

    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $response['error'] = "All fields are required.";
        echo json_encode($response); exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['error'] = "Invalid email address.";
        echo json_encode($response); exit;
    }

    if ($password !== $confirm_password) {
        $response['error'] = "Passwords do not match.";
        echo json_encode($response); exit;
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $profile_picture_path = "uploads/default-profile.png";

    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $profile_picture = $_FILES['profile_picture'];
        $file_name = time() . "_" . preg_replace("/[^a-zA-Z0-9.\-_]/", "", basename($profile_picture['name']));
        $target_path = $upload_dir . $file_name;

        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $max_size = 2 * 1024 * 1024;

        if (!in_array($profile_picture['type'], $allowed_types) || !in_array($file_ext, $allowed_ext)) {
            $response['error'] = "Invalid image format.";
            echo json_encode($response); exit;
        }

        if ($profile_picture['size'] > $max_size) {
            $response['error'] = "File too large (max 2MB).";
            echo json_encode($response); exit;
        }

        if (!move_uploaded_file($profile_picture['tmp_name'], $target_path)) {
            $response['error'] = "Image upload failed.";
            echo json_encode($response); exit;
        }

        $profile_picture_path = $target_path;
    }

    $json_file = 'users.json';
    $existing_data = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : ['users' => []];

    foreach ($existing_data['users'] as $user) {
        if ($user['username'] === $username) {
            $response['error'] = "Username already exists.";
            echo json_encode($response); exit;
        }
        if ($user['email'] === $email) {
            $response['error'] = "Email already registered.";
            echo json_encode($response); exit;
        }
    }

    $new_user = [
        'user_id' => uniqid('user_', true),
        'username' => $username,
        'email' => $email,
        'password' => $hashed_password,
        'profile_picture' => $profile_picture_path,
        'role' => $role,
        'last_active' => time()
    ];

    $existing_data['users'][] = $new_user;

    if (file_put_contents($json_file, json_encode($existing_data, JSON_PRETTY_PRINT)) === false) {
        $response['error'] = "Failed to save user.";
        echo json_encode($response); exit;
    }

    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'suriyamass9442@gmail.com'; // Change this
        $mail->Password = 'qiuzdeijpixojstu';          // Change to App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('suriyamass9442@gmail.com', 'Loan System');
        $mail->addAddress($email, $username);
        $mail->isHTML(true);
        $mail->Subject = 'Welcome to Loan System';
        $mail->Body = "
            <h3>Hello $username!</h3>
            <p>Thank you for signing up. You can now log in and apply for loans.</p>
            <p><a href='http://localhost:8080/PHPLOAN/index.php'>Login Now</a></p>
        ";

        $mail->send();
        $response['success'] = "Signup successful! Confirmation email sent.";
    } catch (Exception $e) {
        $response['success'] = "Signup successful, but email failed: " . $mail->ErrorInfo;
    }

    echo json_encode($response); exit;
}
?>
