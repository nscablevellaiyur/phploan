<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>LoanPro Systems</title>
  <link rel="stylesheet" href="ss.css"/>
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <style>
    .btn {
      background: #ffcc00;
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.3s, transform 0.2s ease-in-out;
    }
    .btn:hover {
      background: #ff9900;
      transform: scale(1.05);
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <header>
      <nav>
        <div class="logo">NeoLoan Systems</div>
        <div class="menu-toggle" onclick="toggleMenu()">☰</div>
        <ul id="navMenu">
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#loan-system">Loan System</a></li>
          <li><a href="#testimonials">Testimonials</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
    </header>

    <!-- Content sections -->
    <section id="home" class="hero" data-aos="fade-up">
      <h1>Smart Loan Management Software</h1>
      <p>Streamline your lending operations with LoanPro’s secure and automated platform.</p>
      <a href="#contact" class="btn">Request a Demo</a>
    </section>

    <section id="about" data-aos="fade-right">
      <h2>About LoanPro</h2>
      <p>We deliver a modern loan management system for microfinance, cooperatives, and lending businesses. Automate workflows, track loans, and improve performance.</p>
    </section>

    <section id="services" data-aos="fade-left">
      <h2>Our Solutions</h2>
      <div class="service-cards">
        <div class="card" data-aos="zoom-in">
          <h3>Loan Origination</h3>
          <p>Process applications and verify clients digitally.</p>
        </div>
        <div class="card" data-aos="zoom-in">
          <h3>Repayment Tracking</h3>
          <p>Monitor due dates, late fees, and client history.</p>
        </div>
        <div class="card" data-aos="zoom-in">
          <h3>Reports & Analytics</h3>
          <p>Access real-time performance dashboards.</p>
        </div>
        <div class="card" data-aos="zoom-in">
          <h3>Client Portal</h3>
          <p>Borrowers can log in, check status, and pay online.</p>
        </div>
      </div>
    </section>

    <section id="loan-system" data-aos="fade-up">
      <h2>Loan Management System</h2>
      <p>Our PHP-powered Loan Management System offers a secure and user-friendly backend for managing client loans, repayments, reports, and more. It includes:</p>
      <ul>
        <li>Loan Origination & Approval Workflow</li>
        <li>Automated Repayment Tracking</li>
        <li>Client Account Management</li>
        <li>Customizable Reports & Dashboards</li>
        <li>User Role Management (Admins, Staff, Clients)</li>
      </ul>
      <p>You can access the loan management portal below:</p>
      <br>
      <form action="./Login/login.php">
        <button type="submit" class="btn">User Login</button>
      </form>
      <form action="./dashboard/OfficerLogin.php">
        <button type="submit" class="btn">Officer Login</button>
      </form>
    </section>

    <section id="testimonials" data-aos="fade-up">
      <h2>What Clients Say</h2>
      <blockquote>
        “LoanPro helped us cut admin time in half.”
        <cite>– John D., MicroTrust</cite>
      </blockquote>
      <blockquote>
        “Excellent system and responsive support.”
        <cite>– Sarah K., QuickFinance</cite>
      </blockquote>
    </section>

    <section id="contact" data-aos="fade-up">
      <h2>Contact Us</h2>
      <form id="contactForm" method="POST" action="./dashboard/submitrequest.php">
        <input type="text" name="name" placeholder="Your Name" required />
        <input type="email" name="email" placeholder="Your Email" required />
        <input type="tel" name="phone" placeholder="Your Phone (optional)" pattern="[0-9]{10}" />
        <textarea name="message" placeholder="Your Message" required></textarea>
        <button type="submit" class="btn">Submit</button>
      </form>
      <p>Email: support@loanprosystems.com | Phone: +1 (800) 123-4567</p>
    </section>
  </div>
  <br>
  <br>

  <footer>
    <p>&copy; 2025 LoanPro Systems |
      <a href="#">Facebook</a> |
      <a href="#">Twitter</a> |
      <a href="#">LinkedIn</a>
    </p>
  </footer>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init();
    function toggleMenu() {
      const menu = document.getElementById('navMenu');
      menu.classList.toggle('show');
    }
    document.querySelectorAll('#navMenu a').forEach(link => {
      link.addEventListener('click', () => {
        document.getElementById('navMenu').classList.remove('show');
      });
    });
  </script>
</body>
</html>
