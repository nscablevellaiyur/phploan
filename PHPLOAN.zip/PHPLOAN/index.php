<?php
// After successful login check
header("Location: Login/login.php");
exit;
?>