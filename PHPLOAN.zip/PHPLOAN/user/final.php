<?php

require '../includes/functions.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loanId = $_POST['loan_id'] ?? '';
    $bankName = trim($_POST['bank_name'] ?? '');
    $branchCode = trim($_POST['branch_code'] ?? '');
    $ifscCode = trim($_POST['ifsc_code'] ?? '');
    $accountNumber = trim($_POST['account_number'] ?? '');
    $confirmAccountNumber = trim($_POST['confirm_account_number'] ?? '');
    $accountName = trim($_POST['account_name'] ?? '');

    if ($accountNumber !== $confirmAccountNumber) {
        die("Account numbers do not match.");
    }

    $loans = read_json('../data/loans.json');
    $updated = false;

    foreach ($loans as &$loan) {
        if ($loan['id'] == $loanId && $loan['username'] === $_SESSION['username']) {
            $loan['bank_details'] = [
                'bank_name' => $bankName,
                'branch_code' => $branchCode,
                'ifsc_code' => $ifscCode,
                'account_number' => $accountNumber,
                'account_name' => $accountName,
            ];
            // $loan['status'] = 'bank_info_submitted'; // status update removed
            $updated = true;
            break;
        }
    }

    if ($updated) {
        write_json('../data/loans.json', $loans);
        header("Location: final_confirmation.php?loan_id=$Id" . urlencode($loanId));
        exit;
    } else {
        echo "<p style='text-align:center; color:red;'>Loan not found or access denied.</p>";
    }
} else {
    header("Location: dashboard.php");
    exit;
}
?>