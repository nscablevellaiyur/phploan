

<?php
$activePage = 'emischedule';
$onlyHeaderCss = true;
include '../../header.php';
?>


<?php

if (
    !isset($_SESSION['role']) || 
    !in_array($_SESSION['role'], ['admin', 'user', 'officer'])
) {
    header("Location: ../Login/login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'Suriya';
$paymentDir = 'data/payments/';
$userPaymentFile = $paymentDir . $username . '.json';
$loan = null;

if (file_exists($userPaymentFile)) {
    $loan = json_decode(file_get_contents($userPaymentFile), true);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>EMI Schedule</title>
    <style>
    
    
    
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f9;
            padding: 20px;
        }
        main.scroll-area {
            flex: 1;
            overflow-y: auto;
            overflow-x: auto;
            padding: 20px;
        }
        

        .container {
            background: white;
            padding: 20px;
            max-width: 950px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.15);
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        .filter-box {
            text-align: center;
            margin-bottom: 20px;
        }

        .filter-box input {
            padding: 8px 10px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th {
            background: #007bff;
            color: white;
        }

        .row-paid {
            background-color: #e6ffed;
        }

        .row-pending {
            background-color: #fff7e6;
        }

        .paid {
            color: green;
            font-weight: bold;
        }

        .pending {
            color: orange;
            font-weight: bold;
        }
    </style>
</head>
<body>
<main class="scroll-area">
<div class="container">
<br>
<br>
    <h2>Your EMI Schedule</h2>

    <?php if ($loan): ?>
        <p><strong>Loan Type:</strong> <?= htmlspecialchars($loan['loan_type']) ?></p>
        <p><strong>Total Loan Amount:</strong> ₹<?= number_format($loan['total_payable'], 2) ?></p>
        <p><strong>Monthly EMI:</strong> ₹<?= number_format($loan['monthly_emi'], 2) ?></p>
        <p><strong>Duration:</strong> <?= $loan['duration'] ?> months</p>

        <div class="filter-box">
            <input type="text" id="filterInput" placeholder="Search month or status (e.g., Paid, January)">
        </div>

        <table id="emiTable">
            <thead>
                <tr>
                    <th>Month</th>
                    <th>Due Date</th>
                    <th>Status</th>
                    <th>Paid Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($loan['payments'] as $payment): 
                    $statusClass = strtolower($payment['status']) === 'paid' ? 'row-paid' : 'row-pending';
                ?>
                    <tr class="<?= $statusClass ?>">
                        <td><?= htmlspecialchars($payment['month']) ?></td>
                        <td><?= htmlspecialchars($payment['due_date']) ?></td>
                        <td class="<?= strtolower($payment['status']) ?>"><?= htmlspecialchars($payment['status']) ?></td>
                        <td>₹<?= number_format($payment['paid_amount'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No EMI schedule found. Please generate an EMI schedule first.</p>
    <?php endif; ?>
</div>

<script>
    const filterInput = document.getElementById('filterInput');
    filterInput.addEventListener('keyup', function () {
        const filter = this.value.toLowerCase();
        const rows = document.querySelectorAll('#emiTable tbody tr');

        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(filter) ? '' : 'none';
        });
    });
</script>

</body>

<br>
<br>
</main>
</html>
<?php include '../../footer.php'; ?>