<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generateAjax'])) {
    session_start();
    $username = $_SESSION['username'];
    $email = $_SESSION['email'] ?? 'default@example.com'; // Use session email or a default

    $summaryFile = 'confirmed_loans_summary.json';
    $paymentDir = 'data/payments/';
    $userPaymentFile = $paymentDir . $username . '.json';

    header('Content-Type: application/json');

    if (!is_dir($paymentDir)) {
        mkdir($paymentDir, 0777, true);
    }

    $loanData = json_decode(file_get_contents($summaryFile), true);
    $loan = null;
    foreach ($loanData as $item) {
        if ($item['username'] === $username) {
            $loan = $item;
            break;
        }
    }

    if (!$loan) {
        echo json_encode(['status' => 'error', 'message' => 'No confirmed loan found.']);
        exit;
    }

    if (file_exists($userPaymentFile)) {
        echo json_encode(['status' => 'warning', 'message' => 'Schedule already generated.']);
        exit;
    }

    $monthlyEMI = round($loan['total_payable'] / $loan['duration'], 2);
    $startDate = new DateTime();
    $payments = [];

    for ($i = 1; $i <= $loan['duration']; $i++) {
        $dueDate = (clone $startDate)->modify("+$i month");
        $payments[] = [
            "month" => $i,
            "due_date" => $dueDate->format('Y-m-d'),
            "status" => "Pending",
            "paid_amount" => 0,
            "remaining_amount" => $monthlyEMI
        ];
    }

    $userData = [
        "username" => $username,
        "email" => $email, // Added email field
        "loan_type" => $loan['loan_type_name'],
        "duration" => $loan['duration'],
        "monthly_emi" => $monthlyEMI,
        "total_payable" => $loan['total_payable'],
        "payments" => $payments
    ];

    file_put_contents($userPaymentFile, json_encode($userData, JSON_PRETTY_PRINT));
    echo json_encode(['status' => 'success', 'message' => 'EMI schedule generated successfully.']);
    exit;
}
?>