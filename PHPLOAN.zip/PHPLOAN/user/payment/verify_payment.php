<?php

$activePage = 'emischedule';
$onlyHeaderCss = true;
include '../../header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'officer') {
    die("Access denied. You must be an officer to verify payments.");
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require_once __DIR__ . '/../../phpmailer/phpmailer/src/Exception.php';
require_once __DIR__ . '/../../phpmailer/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/../../phpmailer/phpmailer/src/SMTP.php';

function sendPaymentStatusEmail($toEmail, $username, $status, $month, $emiAmount, $paidAmount, $remainingAmount) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'suriyamass9442@gmail.com';
        $mail->Password   = 'qiuzdeijpixojstu';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('suriyamass9442@gmail.com', 'Loan Service');
        $mail->addAddress($toEmail, $username);
        $mail->isHTML(true);
        $mail->Subject = 'EMI Payment Status Updated';

        $body = "
            Dear $username,<br><br>
            Your payment status for <strong>Month $month</strong> has been updated to <strong>$status</strong>.<br><br>
            <strong>EMI Details:</strong><br>
            - Total EMI Amount: ₹" . number_format($emiAmount, 2) . "<br>
            - Paid Amount: ₹" . number_format($paidAmount, 2) . "<br>";

        if ($status === 'Partial' || $status === 'Partial Verified') {
            $body .= "- Remaining Amount: ₹" . number_format($remainingAmount, 2) . "<br>";
        }

        $body .= "<br>Thank you,<br>Loan Service Team";

        $mail->Body = $body;
        $mail->send();
    } catch (Exception $e) {
        error_log("Mailer Error: {$mail->ErrorInfo}");
    }
}

$paymentDir = 'data/payments/';
$allPayments = [];

foreach (glob($paymentDir . "*.json") as $file) {
    $username = basename($file, '.json');
    $paymentData = json_decode(file_get_contents($file), true);

    if ($paymentData !== null) {
        foreach ($paymentData['payments'] as $payment) {
            if ($payment['status'] === 'Paid' || $payment['status'] === 'Partial') {
                $allPayments[] = [
                    'username' => $username,
                    'month' => $payment['month'],
                    'emi_amount' => $paymentData['monthly_emi'],
                    'status' => $payment['status'],
                    'paid_amount' => $payment['paid_amount'] ?? null,
                    'remaining_amount' => $payment['remaining_amount'] ?? null,
                    'email' => $paymentData['email'] ?? null
                ];
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify'])) {
    $username = $_POST['username'];
    $month = (int)$_POST['month'];
    $userPaymentFile = $paymentDir . $username . '.json';

    if (file_exists($userPaymentFile)) {
        $paymentData = json_decode(file_get_contents($userPaymentFile), true);
        $paymentUpdated = false;

        foreach ($paymentData['payments'] as &$payment) {
            if ($payment['month'] === $month) {
                if ($payment['status'] === 'Paid') {
                    $payment['status'] = 'Verified';
                    $paymentUpdated = true;
                    $message = "Status updated to 'Verified' for $username (Month $month).";
                } elseif ($payment['status'] === 'Partial') {
                    $payment['status'] = 'Partial Verified';
                    $paymentUpdated = true;
                    $message = "Status updated to 'Partial Verified' for $username (Month $month).";
                }

                if ($paymentUpdated && isset($paymentData['email'])) {
                    sendPaymentStatusEmail(
                        $paymentData['email'],
                        $username,
                        $payment['status'],
                        $month,
                        $paymentData['monthly_emi'],
                        $payment['paid_amount'],
                        $payment['remaining_amount']
                    );
                }
                break;
            }
        }

        if ($paymentUpdated) {
            file_put_contents($userPaymentFile, json_encode($paymentData, JSON_PRETTY_PRINT));
            $updatedUser = $username;
            $updatedMonth = $month;
        } else {
            $message = "No update needed. Payment might already be verified.";
        }
    } else {
        $message = "No payment record found for $username.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Verify Payment</title>
    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
            padding: 30px;
        }

        main.scroll-area {
            flex: 1;
            overflow-y: auto;
            overflow-x: auto;
            padding: 20px;
        }

        .container {
            background: white;
            padding: 20px;
            max-width: 900px;
            width: 600%;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
            animation: fadeIn 1s ease-in-out;
        }

        h2 {
            text-align: center;
            animation: slideDown 0.8s ease-in-out;
        }

        .success {
            color: green;
            font-weight: bold;
            text-align: center;
            animation: fadeIn 0.5s ease-in;
        }

        .error {
            color: red;
            font-weight: bold;
            text-align: center;
            animation: fadeIn 0.5s ease-in;
        }

        .btn {
            padding: 6px 14px;
            background: green;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background: darkgreen;
        }

        .btn:disabled {
            background: gray !important;
            cursor: not-allowed;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }

        tbody tr {
            animation: slideIn 0.5s ease forwards;
            opacity: 0;
        }

        tbody tr:hover {
            background-color: #f9f9f9;
            transition: background-color 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.98); }
            to { opacity: 1; transform: scale(1); }
        }

        @keyframes slideIn {
            from { transform: translateY(10px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
<br><br><br>
<h2>Verify Payment</h2>
<main class="scroll-area">
<div class="container">

    <?php if (isset($message)): ?>
        <p id="statusMessage" class="<?= strpos($message, 'updated') !== false ? 'success' : 'error' ?>">
            <?= htmlspecialchars($message) ?>
        </p>
    <?php endif; ?>

    <?php if (isset($updatedUser) && isset($updatedMonth)): ?>
        <script>
            var updatedUser = <?= json_encode($updatedUser) ?>;
            var updatedMonth = <?= json_encode($updatedMonth) ?>;
        </script>
    <?php endif; ?>

    <h3>Paid or Partial Payments</h3>
    <?php if (!empty($allPayments)): ?>
        <table>
            <thead>
                <tr>
                    <th>User</th>
                    <th>Month</th>
                    <th>EMI Amount</th>
                    <th>Status</th>
                    <th>Paid Amount</th>
                    <th>Remaining Amount</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($allPayments as $payment): ?>
                    <tr>
                        <td><?= htmlspecialchars($payment['username']) ?></td>
                        <td><?= $payment['month'] ?></td>
                        <td>₹<?= number_format($payment['emi_amount'], 2) ?></td>
                        <td><?= $payment['status'] ?></td>
                        <td><?= $payment['paid_amount'] !== null ? '₹' . number_format($payment['paid_amount'], 2) : 'N/A' ?></td>
                        <td><?= $payment['remaining_amount'] !== null ? '₹' . number_format($payment['remaining_amount'], 2) : 'N/A' ?></td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="username" value="<?= htmlspecialchars($payment['username']) ?>">
                                <input type="hidden" name="month" value="<?= htmlspecialchars($payment['month']) ?>">
                                <button type="submit" name="verify" class="btn" onclick="return confirm('Are you sure you want to update this payment status?');">Update Status</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No 'Paid' or 'Partial' payments to verify.</p>
    <?php endif; ?>
</div>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    if (typeof updatedUser !== 'undefined' && typeof updatedMonth !== 'undefined') {
        const rows = document.querySelectorAll("table tbody tr");
        rows.forEach(row => {
            const username = row.querySelector("input[name='username']").value;
            const month = row.querySelector("input[name='month']").value;
            if (username === updatedUser && month === updatedMonth.toString()) {
                const button = row.querySelector("button[name='verify']");
                button.textContent = 'Updated';
                button.disabled = true;
            }
        });
    }
});
</script>

</body>
</html>
<?php include '../../footer.php'; ?>
