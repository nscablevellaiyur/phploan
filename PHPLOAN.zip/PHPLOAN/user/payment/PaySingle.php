<?php
$activePage = 'emischedule';
$onlyHeaderCss = true;
include '../../header.php';
?>



<?php

$username = $_SESSION['username'];

$summaryFile = 'confirmed_loans_summary.json';
$paymentDir = 'data/payments/';
$userPaymentFile = $paymentDir . $username . '.json';
$message = '';
$loan = null;

// Ensure payment directory exists
if (!is_dir($paymentDir)) {
    mkdir($paymentDir, 0777, true);
}

// Load confirmed loans and find the user's loan
$loanData = json_decode(file_get_contents($summaryFile), true);
foreach ($loanData as $item) {
    if ($item['username'] === $username) {
        $loan = $item;
        break;
    }
}

// Generate payment schedule if not already created
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate']) && $loan) {
    if (file_exists($userPaymentFile)) {
        $message = "Schedule already generated for $username.";
    } else {
        $monthlyEMI = round($loan['total_payable'] / $loan['duration'], 2);
        $startDate = new DateTime();
        $payments = [];

        for ($i = 1; $i <= $loan['duration']; $i++) {
            $dueDate = (clone $startDate)->modify("+$i month");
            $payments[] = [
                "month" => $i,
                "due_date" => $dueDate->format('Y-m-d'),
                "status" => "Pending",
                "paid_amount" => 0,
                "remaining_amount" => $monthlyEMI
            ];
        }

        $userData = [
            "username" => $username,
            "loan_type" => $loan['loan_type_name'],
            "duration" => $loan['duration'],
            "monthly_emi" => $monthlyEMI,
            "total_payable" => $loan['total_payable'],
            "payments" => $payments
        ];

        file_put_contents($userPaymentFile, json_encode($userData, JSON_PRETTY_PRINT));
        $message = "Payment schedule generated successfully.";
    }
}

// Load user's payment data if it exists
$userPayment = file_exists($userPaymentFile) ? json_decode(file_get_contents($userPaymentFile), true) : null;
?>
<!DOCTYPE html>
<html>
<head>
    <title>EMI Schedule</title>
    <style>
        body { font-family: Arial; background: #f2f2f2; padding: 30px; }
        main.scroll-area {
            flex: 1;
            overflow-y: auto;
            overflow-x: auto;
            padding: 20px;
        }
        .container { background: white; padding: 20px; max-width: 800px; margin: auto; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.15); }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        th { background: #007bff; color: white; }
        h2 { text-align: center; }
        .paid, .verified { color: green; font-weight: bold; }
        .pending, .partial, .remaining { color: orange; font-weight: bold; }
        button, .pay-button {
            padding: 6px 12px;
            background: green;
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
        }
        .message { margin-top: 15px; font-weight: bold; color: darkblue; text-align: center; }
    </style>
</head>
<body>
<main class="scroll-area">
<div class="container">
<br>
    <h2>EMI Payment Schedule</h2>
    <?php
        $totalPaid = 0;
        foreach ($userPayment['payments'] as $pay) {
            $totalPaid += $pay['paid_amount'];
        }
        $totalPayable = $userPayment['total_payable'];
    ?>

    <?php if ($loan): ?>
        <div style="display: flex; justify-content: space-between; margin-top: 20px;">
            <div style="flex: 1;">
                <p><strong>Name:</strong> <?= htmlspecialchars($username) ?></p>
                <p><strong>Loan Type:</strong> <?= htmlspecialchars($loan['loan_type_name']) ?></p>
                <p><strong>Loan Amount:</strong> ₹<?= number_format($loan['total_payable'], 2) ?></p>
                <p><strong>Duration:</strong> <?= $loan['duration'] ?> months</p>
                <p><strong>Monthly EMI:</strong> ₹<?= number_format(round($loan['total_payable'] / $loan['duration'], 2), 2) ?></p>
            </div>
            <div style="flex: 1; text-align: right; font-weight: bold;">
                <p>Total Paid: ₹<?= number_format($totalPaid, 2) ?></p>
                <p>Loan Amount: ₹<?= number_format($totalPayable, 2) ?></p>
                <?php if ($totalPaid < $totalPayable): ?>
                    <p style="color: orange;">Amount remaining: ₹<?= number_format($totalPayable - $totalPaid, 2) ?></p>
                <?php else: ?>
                    <p style="color: green;">Loan fully paid.</p>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!$userPayment): ?>
            <form method="POST">
                <input type="hidden" name="generate" value="1">
                <button type="submit">Generate Schedule</button>
            </form>
        <?php endif; ?>

        <?php if ($message): ?>
            <div class="message"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <?php if ($userPayment): ?>
            <table>
                <tr>
                    <th>Month</th>
                    <th>Due Date</th>
                    <th>Amount Due (₹)</th>
                    <th>Status / Action</th>
                </tr>
                <?php
                $firstPendingShown = false;
                $currentDate = new DateTime();
                foreach ($userPayment['payments'] as $pay):
                    $status = $pay['status'];
                    $remainingAmount = $pay['remaining_amount'];
                    $paidAmount = $pay['paid_amount'];
                    $dueDate = new DateTime($pay['due_date']);
                    $isDue = $currentDate->format('Y-m') === $dueDate->format('Y-m');
                ?>
                    <tr>
                        <td><?= $pay['month'] ?></td>
                        <td><?= $pay['due_date'] ?></td>
                        <td>
                            <?php
                            if ($status === 'Partial' || $status === 'Remaining') {
                                echo number_format($remainingAmount, 2);
                            } else {
                                echo number_format($userPayment['monthly_emi'], 2);
                            }
                            ?>
                        </td>
                        <td class="<?= strtolower($status) ?>">
                            <?php if ($isDue && ($status === 'Pending' || $status === 'Partial Verified' ||$status === 'Partial'|| $status === 'Remaining') && !$firstPendingShown): ?>
                                <a href="makepayment.php?month=<?= $pay['month'] ?>&amount=<?= $remainingAmount ?>&redirect=paysingle.php" class="pay-button">Pay</a>

                                <?php $firstPendingShown = true; ?>
                                <?php if ($status !== 'Pending'): ?>
                                    <br><small>Paid ₹<?= number_format($paidAmount, 2) ?> | Remaining ₹<?= number_format($remainingAmount, 2) ?></small>
                                <?php endif; ?>
                            <?php elseif ($status === 'Partial' || $status === 'Remaining'): ?>
                                <span><?= $status ?> - ₹<?= number_format($paidAmount, 2) ?> | Remaining ₹<?= number_format($remainingAmount, 2) ?></span>
                            <?php elseif ($status === 'Verified'): ?>
                                <span>Verified - ₹<?= number_format($paidAmount, 2) ?> | Remaining ₹<?= number_format($remainingAmount, 2) ?></span>
                            <?php else: ?>
                                <?= $status ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    <?php else: ?>
        <p style="color:red;">No confirmed loan found for user.</p>
    <?php endif; ?>
</div>
</body>
</main>
</html>
<br><br>
<?php include '../../footer.php'; ?>
