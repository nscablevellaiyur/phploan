<?php
$activePage = 'emischedule';
$onlyHeaderCss = true;
include '../../header.php';


if (!isset($_SESSION['username'])) {
    header("Location: ../../login.php");
    exit;
}

$username = $_SESSION['username'];

$paymentDir = 'data/payments/';
$userPaymentFile = $paymentDir . $username . '.json';

$month = isset($_GET['month']) ? (int)$_GET['month'] : 0;
$redirectPage = isset($_GET['redirect']) ? basename($_GET['redirect']) : 'paysingle.php';

$message = '';
$redirect = false;
$remainingAmount = 0;

if (!file_exists($userPaymentFile)) {
    die("Payment record not found.");
}
$paymentData = json_decode(file_get_contents($userPaymentFile), true);
$emi = $paymentData['monthly_emi'] ?? 0;

$entry = null;
foreach ($paymentData['payments'] as $i => $p) {
    if ((int)$p['month'] === $month && in_array($p['status'], ['Pending', 'Partial Verified', 'Partial', 'Remaining'])) {
        $entryIndex = $i;
        $entry = &$paymentData['payments'][$i];
        $remainingAmount = $entry['remaining_amount'];
        break;
    }
}

if (!$entry) {
    die("Invalid or already fully paid month.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customAmount = (float)($_POST['custom_amount'] ?? 0);
    if ($customAmount <= 0) {
        die("Invalid payment amount.");
    }

    $paidAmount = $customAmount;

    if ($paidAmount < $remainingAmount) {
        $entry['remaining_amount'] = round($remainingAmount - $paidAmount, 2);
        $entry['status'] = 'Partial';
        $entry['paid_amount'] += $paidAmount;
    } elseif ($paidAmount == $remainingAmount) {
        $entry['remaining_amount'] = 0;
        $entry['status'] = 'Paid';
        $entry['paid_amount'] += $paidAmount;
    } else {
        $overPay = $paidAmount - $remainingAmount;
        $entry['remaining_amount'] = 0;
        $entry['status'] = 'Paid';
        $entry['paid_amount'] += $remainingAmount;

        for ($i = $entryIndex + 1; $i < count($paymentData['payments']); $i++) {
            $nextEntry = &$paymentData['payments'][$i];
            if (in_array($nextEntry['status'], ['Pending', 'Partial', 'Remaining']) && $overPay > 0) {
                $reduceAmount = min($nextEntry['remaining_amount'], $overPay);
                $nextEntry['remaining_amount'] = round($nextEntry['remaining_amount'] - $reduceAmount, 2);
                $nextEntry['paid_amount'] += $reduceAmount;
                $overPay -= $reduceAmount;
                $nextEntry['status'] = $nextEntry['remaining_amount'] <= 0 ? 'Paid' : 'Partial';
            }
            if ($overPay <= 0) break;
        }
    }

    $message = "Payment for month $month processed. Status: " . $entry['status'] . ". Redirecting...";
    $redirect = true;
    file_put_contents($userPaymentFile, json_encode($paymentData, JSON_PRETTY_PRINT));
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Make Payment</title>
    <?php if ($redirect): ?>
        <meta http-equiv="refresh" content="3;url=<?= htmlspecialchars($redirectPage) ?>">
    <?php endif; ?>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #e0f7fa, #fff3e0);
            padding: 30px;
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .container {
            background: white;
            width: 70%;
            padding: 25px;
            max-width: 550px;
            margin: auto;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            animation: slideIn 0.8s ease;
        }

        @keyframes slideIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        h2 {
            text-align: center;
            color: #00796b;
        }

        .success {
            color: green;
            font-weight: bold;
            text-align: center;
        }

        .btn {
            padding: 10px 24px;
            background: linear-gradient(to right, #43cea2, #185a9d);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            display: block;
            margin: 20px auto 0;
            transition: transform 0.2s ease;
        }

        .btn:hover {
            transform: scale(1.05);
        }

        .payment-option {
            margin: 15px 0;
            font-size: 16px;
            animation: fadeIn 0.8s ease;
        }

        .rupee-input {
            position: relative;
            width: 100%;
            animation: inputGlow 0.8s ease-in-out;
        }

        .rupee-input input {
            width: 90%;
            padding: 10px 12px 10px 28px;
            font-size: 15px;
            border: 2px solid #ccc;
            border-radius: 6px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .rupee-input input:focus {
            border-color: #26a69a;
            box-shadow: 0 0 10px rgba(38, 166, 154, 0.5);
            outline: none;
        }

        .rupee-input::before {
            content: '₹';
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 16px;
            color: #555;
        }

        @keyframes inputGlow {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        input[type="radio"] {
            transform: scale(1.1);
            margin-right: 8px;
        }

        label {
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        label:hover {
            color: #00796b;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Make Payment</h2>
    <p><strong>User:</strong> <?= htmlspecialchars($username) ?></p>
    <p><strong>Month:</strong> <?= $month ?></p>
    <p><strong>Amount Due:</strong> ₹<?= number_format($remainingAmount, 2) ?></p>

    <?php if ($message): ?>
        <p class="success"><?= $message ?></p>
        <p style="text-align:center;">Redirecting to EMI Schedule...</p>
    <?php else: ?>
        <form method="POST">
            <input type="hidden" name="redirect" value="<?= htmlspecialchars($redirectPage) ?>">
            <p>Select payment option:</p>
            <div class="payment-option">
                <label>
                    <input type="radio" name="payment_type" value="full" checked onclick="setAmount(<?= $remainingAmount ?>)">
                    Full Payment (₹<?= number_format($remainingAmount, 2) ?>)
                </label>
            </div>
            <div class="payment-option">
                <label>
                    <input type="radio" name="payment_type" value="partial" onclick="setAmount(<?= round($remainingAmount * 0.7, 2) ?>)">
                    Partial Payment (70%: ₹<?= number_format($remainingAmount * 0.7, 2) ?>)
                </label>
            </div>
            <div class="payment-option">
                <label>
                    <input type="radio" name="payment_type" value="custom" onclick="enableCustom()">
                    Enter Custom Amount:
                </label>
                <br>
                <div class="rupee-input">
                    <input type="number" id="custom_amount" name="custom_amount" min="1" step="0.01" required placeholder="Enter amount">
                </div>
            </div>
            <button type="submit" class="btn">Pay Now</button>
        </form>

        <script>
        function setAmount(amount) {
            const input = document.getElementById('custom_amount');
            input.value = amount;
            input.readOnly = true;
        }

        function enableCustom() {
            const input = document.getElementById('custom_amount');
            input.value = '';
            input.readOnly = false;
        }

        window.onload = function() {
            setAmount(<?= $remainingAmount ?>);
        };
        </script>
    <?php endif; ?>
</div>
</body>
</html>

<?php include '../../footer.php'; ?>
