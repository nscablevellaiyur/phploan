<?php $onlyHeaderCss = true; ?>
<?php include '../header.php'; ?>

<?php

require '../includes/functions.php';

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$loans = read_json('../data/loans.json');
$userLoans = array_filter($loans, fn($loan) => $loan['username'] === $_SESSION['username']);

$selectedLoan = null;
if (isset($_POST['loan_id'])) {
    $loanId = $_POST['loan_id'];
    foreach ($userLoans as $loan) {
        if ($loan['id'] == $loanId) {
            $selectedLoan = $loan;
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Applications</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            text-align: center;
            color: white;
            height: 100vh;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            overflow-y: auto;
        }

        h2 {
            animation: slideDown 1s ease-out;
        }

        .confirm-btn, .next-step-btn {
            background-color: #007BFF;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: transform 0.2s, background-color 0.3s;
        }

        .confirm-btn:hover, .next-step-btn:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        .centered {
            text-align: center;
            margin-top: 20px;
        }

        .container {
            width: 90%;
            max-width: 500px;
            background: rgba(255, 255, 255, 0.1);
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            display: flex;
            flex-direction: column;
            align-items: center;
            animation: fadeIn 1s ease-in-out;
        }

        .container img {
            width: 100px;
            margin-bottom: 20px;
        }

        input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            text-align: center;
            transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
        }

        input:focus {
            transform: scale(1.05);
            box-shadow: 0 0 15px rgba(0, 255, 255, 0.8);
            outline: none;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideDown {
            from { transform: translateY(-30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
<br>
<br>
<br>

<h2>Your Processed Loan Applications</h2>

<?php if ($selectedLoan): ?>
    <div class="container">
        <img src="Logo/gifmaker_me.gif" alt="App Logo">
        <h2>Bank Details Confirmation</h2>
        <form method="post" action="../user/final.php" onsubmit="return validateAccountMatch()">
            <input type="hidden" name="loan_id" value="<?= htmlspecialchars($selectedLoan['id']) ?>">

            <input type="text" id="bank_name" name="bank_name" placeholder="Bank Name" required>
            <input type="text" id="branch_code" name="branch_code" placeholder="Branch Name" required>
            <input type="text" id="ifsc_code" name="ifsc_code" placeholder="IFSC Code" required>
            <input type="text" id="account_number" name="account_number" placeholder="Account Number" required>
            <input type="text" id="confirm_account_number" name="confirm_account_number" placeholder="Confirm Account Number" required>
            <input type="text" id="account_name" name="account_name" placeholder="Account Name" required>

            <div class="centered">
                <button class="confirm-btn" type="submit">Confirm and Proceed</button>
            </div>
        </form>
    </div>

    <script>
        function validateAccountMatch() {
            const accNum = document.getElementById('account_number').value.trim();
            const confirmAccNum = document.getElementById('confirm_account_number').value.trim();
            if (accNum !== confirmAccNum) {
                alert("Account numbers do not match. Please recheck.");
                return false;
            }
            return true;
        }
    </script>
<br>
<br>
<br>
<?php elseif (empty($userLoans)): ?>
    <p class="centered">You have no applications yet.</p>

<?php else: ?>
    <?php foreach ($userLoans as $loan): ?>
        <?php if ($loan['status'] === 'approved'): ?>
            <form method="post" style="text-align: center; margin-bottom: 20px;">
                <input type="hidden" name="loan_id" value="<?= htmlspecialchars($loan['id']) ?>">
                <button class="next-step-btn" type="submit">Proceed with Loan #<?= htmlspecialchars($loan['id']) ?></button>
            </form>
        <?php endif; ?>
    <?php endforeach; ?>
<?php endif; ?>

</body>
</html>

<?php include '../footer.php'; ?>