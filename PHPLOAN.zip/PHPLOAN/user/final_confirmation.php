<?php
$activePage = 'finalconfirm';
$onlyHeaderCss = true;
include '../header.php';
?>

<?php

require '../includes/functions.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/phpmailer/src/Exception.php';
require '../phpmailer/phpmailer/src/PHPMailer.php';
require '../phpmailer/phpmailer/src/SMTP.php';

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$loanFound = false;
$message = '';
$loan = [];

$loans = read_json('../data/loans.json');

// Handle loan confirmation (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['loan_id'])) {
    $loanId = $_POST['loan_id'];

    foreach ($loans as $index => $item) {
        if ($item['id'] == $loanId && $item['username'] === $_SESSION['username']) {
            if ($item['status'] !== 'confirmed') {
                $item['status'] = 'confirmed';

                $amount = floatval($item['amount'] ?? 0);
                $interestRate = floatval($item['interest'] ?? 0);
                $duration = intval($item['duration'] ?? 1);

                // Fix document charge: Set to a random percentage between 1% and 3%
                $docRate = rand(1, 3) / 100; // Random rate between 1% and 3%
                $documentCharge = round($amount * $docRate, 2);
                $item['document_charge'] = $documentCharge;

                // Recalculate interest and total payable
                $interestAmount = ($amount * $interestRate) / 100;
                $totalPayable = $amount + $interestAmount;

                $summary = [
                    'username' => $item['username'],
                    'email' => $item['user_id'] ?? '',
                    'loan_type_name' => $item['loan_type_name'] ?? 'N/A',
                    'interest' => $interestRate,
                    'duration' => $duration,
                    'total_payable' => round($totalPayable, 2)
                ];

                // Save to summary file
                $summaryFile = 'payment/confirmed_loans_summary.json';
                $existingSummaries = file_exists($summaryFile) ? json_decode(file_get_contents($summaryFile), true) : [];
                $existingSummaries[] = $summary;
                file_put_contents($summaryFile, json_encode($existingSummaries, JSON_PRETTY_PRINT));

                // Delete from loans
                array_splice($loans, $index, 1);
                write_json('../data/loans.json', $loans);

                // Send email
                $transactionDate = date("d-m-Y H:i:s");
                $referenceNumber = strtoupper(uniqid("REF"));

                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'suriyamass9442@gmail.com';
                    $mail->Password   = 'qiuzdeijpixojstu';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port       = 587;

                    $mail->setFrom('suriyamass9442@gmail.com', 'Loan Service');
                    $mail->addAddress($item['user_id'], $item['username']);

                    $mail->isHTML(true);
                    $mail->Subject = 'Loan Confirmed';
                    $mail->Body = "
                        Dear {$item['username']},<br><br>
                        Your loan has been confirmed. Here are the details:<br><br>

                        <strong>Term:</strong> {$duration} months<br>
                        <strong>Document Charges:</strong> ₹" . number_format($documentCharge, 2) . "<br>
                        <strong>Interest Amount:</strong> ₹" . number_format($interestAmount, 2) . "<br>
                        <strong>Total Payment:</strong> ₹" . number_format($totalPayable, 2) . "<br>
                        <strong>Monthly EMI:</strong> ₹" . number_format($totalPayable / $duration, 2) . "<br>
                        <strong>Total Disbursed:</strong> ₹" . number_format($amount - $documentCharge, 2) . "<br><br>

                        <strong>Note:</strong> Total disbursed amount credited to your account successfully.<br>
                        <strong>Transaction Date:</strong> {$transactionDate}<br>
                        <strong>Reference Number:</strong> {$referenceNumber}<br><br>

                        Thank you for using our Loan Service.
                    ";

                    $mail->send();
                } catch (Exception $e) {
                    // Optionally log the error: $mail->ErrorInfo
                }

                $_SESSION['confirm_message'] = "Your loan has been confirmed and an email has been sent.";
            }

            header("Location: final_confirmation.php?loan_id=$loanId");
            exit;
        }
    }

    $message = "Loan not found or you are not authorized.";
}

// Handle display (GET)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['loan_id'])) {
    $loanId = $_GET['loan_id'];

    foreach ($loans as $item) {
        if ($item['id'] == $loanId && $item['username'] === $_SESSION['username']) {
            $loan = $item;
            $loanFound = true;

            $loanTypes = read_json('../data/loan_types.json');
            foreach ($loanTypes as $type) {
                if (strtolower($type['name']) === strtolower($loan['loan_type_name'] ?? '')) {
                    if (!isset($loan['interest'])) {
                        $loan['interest'] = $type['interest'];
                    }
                    if (!isset($loan['duration'])) {
                        $loan['duration'] = $type['term_months'];
                    }
                    break;
                }
            }

            if (!isset($loan['document_charge'])) {
                // Fix document charge: Randomly set it between 1% and 3% of the loan amount
                $docRate = rand(1, 2) / 100;
                $loan['document_charge'] = round($loan['amount'] * $docRate, 2);
            }

            break;
        }
    }

    if (!$loanFound) {
        $message = "Loan not found or you are not authorized.";
    }
}

if (isset($_SESSION['confirm_message'])) {
    $message = $_SESSION['confirm_message'];
    unset($_SESSION['confirm_message']);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Loan Confirmation</title>
    <style>
      body {
    font-family: 'Segoe UI', sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}


        .message-box {
            display: inline-block;
            background-color: #fff;
            padding: 30px;
            border: 1px solid #ccc;
            box-shadow: 0 2px 10px rgba(0,0,0,0.15);
            border-radius: 10px;
            max-width: 600px;
            text-align: center;
            justify-content: center;
            opacity: 0;
            transform: scale(0.95);
            animation: fadeInZoom 0.8s ease-out forwards;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }

        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #007bff;
            transition: color 0.3s;
        }

        a:hover {
            color: #0056b3;
        }

        p {
            margin: 8px 0;
            opacity: 0;
            animation: fadeSlideIn 0.6s forwards;
        }

        p:nth-of-type(1) { animation-delay: 0.2s; }
        p:nth-of-type(2) { animation-delay: 0.3s; }
        p:nth-of-type(3) { animation-delay: 0.4s; }
        p:nth-of-type(4) { animation-delay: 0.5s; }
        p:nth-of-type(5) { animation-delay: 0.6s; }
        p:nth-of-type(6) { animation-delay: 0.7s; }
        p:nth-of-type(7) { animation-delay: 0.8s; }
        p:nth-of-type(8) { animation-delay: 0.9s; }

        .total-box {
            margin-top: 20px;
            padding: 15px;
            background-color: #f9f9f9;
            border: 1px dashed #ccc;
            border-radius: 8px;
            animation: fadeInZoom 0.8s ease-in-out forwards;
            animation-delay: 1s;
            opacity: 0;
        }

        form {
            margin-top: 20px;
            opacity: 0;
            animation: slideUp 0.8s forwards;
            animation-delay: 1.2s;
        }

        button {
            padding: 10px 20px;
            background: green;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            background: #006400;
        }

        @keyframes fadeInZoom {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        @keyframes fadeSlideIn {
            from {
                opacity: 0;
                transform: translateX(-10px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<br>
<br>
<br>
<div class="message-box">
    <h2 class="<?= $loanFound && ($loan['status'] ?? '') === 'confirmed' ? 'success' : 'error' ?>">
        <?= htmlspecialchars($message) ?>
    </h2>
    
    <h2>Please Check Account Details And Payments</h2>
    
    <?php if ($loanFound): ?>
        <p><strong>Bank:</strong> <?= htmlspecialchars($loan['bank_details']['bank_name'] ?? '') ?></p>
        <p><strong>Branch Code:</strong> <?= htmlspecialchars($loan['bank_details']['branch_code'] ?? '') ?></p>
        <p><strong>IFSC Code:</strong> <?= htmlspecialchars($loan['bank_details']['ifsc_code'] ?? '') ?></p>
        <p><strong>Account Number:</strong> <?= htmlspecialchars($loan['bank_details']['account_number'] ?? '') ?></p>
        <p><strong>Account Holder:</strong> <?= htmlspecialchars($loan['bank_details']['account_name'] ?? '') ?></p>

        <p><strong>Loan Type:</strong> <?= htmlspecialchars($loan['loan_type_name'] ?? 'N/A') ?></p>
        <p><strong>Loan Amount:</strong> ₹<?= number_format($loan['amount'] ?? 0) ?></p>
        <p><strong>Interest (%):</strong> <?= htmlspecialchars($loan['interest'] ?? '0') ?>%</p>
        <p><strong>Term:</strong> <?= htmlspecialchars($loan['duration'] ?? 'N/A') ?> months</p>
        <p><strong>Document Charges:</strong> ₹<?= number_format($loan['document_charge'] ?? 0) ?></p>

        <?php
            $amount = floatval($loan['amount'] ?? 0);
            $interest = floatval($loan['interest'] ?? 0);
            $duration = intval($loan['duration'] ?? 1);
            $docCharge = floatval($loan['document_charge'] ?? 0);

            $interestAmount = ($amount * $interest) / 100;
            $totalPayment = $amount + $interestAmount;
            $monthlyEMI = $totalPayment / $duration;
            $totalDisbursed = $amount - $docCharge;
        ?>

        <div class="total-box">
            <p><strong>Interest Amount:</strong> ₹<?= number_format($interestAmount, 2) ?></p>
            <p><strong>Total Payment:</strong> ₹<?= number_format($totalPayment, 2) ?></p>
            <p><strong>Monthly EMI:</strong> ₹<?= number_format($monthlyEMI, 2) ?></p>
            <p><strong>Total Disbursed:</strong> ₹<?= number_format($totalDisbursed, 2) ?></p>
        </div>

        <form method="POST" onsubmit="return showConfirmationPopup()">
            <input type="hidden" name="loan_id" value="<?= htmlspecialchars($loan['id']) ?>">
            <button type="submit">Confirm Details</button>
        </form>
    <?php endif; ?>

    
</div>

<script>
    function showConfirmationPopup() {
        var confirmation = confirm("Are you sure you want to confirm the loan details?");
        if (confirmation) {
            // Show popup with confirmation message
            alert("Loan confirmed! You will be redirected shortly.");

            // Redirect after 2 seconds
            setTimeout(function() {
                window.location.href = "../Dashboard/index.php"; // Redirect to loan status page
            }, 2000);  // 2-second delay for popup
            return true;  // Proceed with form submission
        }
        return false;  // Prevent form submission if canceled
    }
</script>

</body>
</html>

<?php include '../footer.php'; ?>
