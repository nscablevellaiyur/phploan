<?php
$activePage = 'loanstatus';
$onlyHeaderCss = true;
include '../header.php';
?>

<?php

require '../includes/functions.php';

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$loans = read_json('../data/loans.json');
$loanTypes = read_json('../data/loan_types.json');

// Get only loans belonging to the current user
$userLoans = array_filter($loans, fn($loan) => $loan['username'] === $_SESSION['username']);
?>


<br>
<br>
<br>
<br>
<br>
<br>
<h2>Your Processed Loan Applications</h2>

<style>
    h2 {
        opacity: 0;
        transform: translateY(-20px);
        animation: fadeDown 0.6s ease-out forwards;
        text-align: center;
        font-size: 2em;
        color: #333;
        margin-top: 30px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .responsive-table {
        width: 100%;
        overflow-x: auto;
        margin: 0 auto;
    }

    table {
        width: 80%;
        min-width: 600px;
        margin: 20px auto;
        border-collapse: collapse;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        background-color: #fff;
        animation: fadeIn 1s ease-in;
    }

    @media (max-width: 600px) {
        table {
            width: 100%;
            font-size: 14px;
        }

        th, td {
            padding: 8px;
        }
    }

    th {
        background-color: #007bff;
        color: #fff;
        padding: 12px;
        font-weight: normal;
        font-size: 16px;
    }

    td {
        padding: 14px;
        text-align: left;
        font-size: 15px;
    }

    tr {
        opacity: 0;
        transform: scale(0.95);
        animation: rowPop 0.4s forwards;
        animation-delay: var(--delay);
        transition: background-color 0.3s ease;
    }

    tr:hover {
        background-color: #f3faff;
    }

    tr.approved {
        background-color: #e6ffec;
    }

    .next-step-btn {
        padding: 6px 12px;
        background: #28a745;
        color: white;
        border: none;
        cursor: pointer;
        border-radius: 4px;
        font-size: 14px;
    }

    .next-step-btn:hover {
        background: #218838;
    }

    @keyframes fadeDown {
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    @keyframes rowPop {
        to {
            opacity: 1;
            transform: scale(1);
        }
    }
</style>


<?php if (empty($userLoans)): ?>
    <p style="text-align: center; font-size: 18px; color: #555;">You have no applications yet.</p>
<?php else: ?>
    <div class="responsive-table">
    <br>

        <table>
            <tr>
                <th>Type</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Submitted</th>
                <th>Reviewed</th>
                <th>Next Step</th>
            </tr>
            <?php 
            $i = 0;
            foreach ($userLoans as $loan): 
                $delay = 0.2 + ($i * 0.1);
                $approvedClass = $loan['status'] === 'approved' ? 'approved' : '';
            ?>
                <tr class="<?= $approvedClass ?>" style="--delay: <?= $delay ?>s;">
                    <td><?= htmlspecialchars($loan['loan_type_name']) ?></td>
                    <td>₹<?= number_format($loan['amount'], 2) ?></td>
                    <td><?= htmlspecialchars(ucfirst($loan['status'])) ?></td>
                    <td><?= htmlspecialchars($loan['submitted_at']) ?></td>
                    <td><?= htmlspecialchars($loan['reviewed_at'] ?? 'Not reviewed') ?></td>
                    <td>
                        <?php if ($loan['status'] === 'approved'): ?>
                            <form method="POST" action="../user/next_step.php">
                                <input type="hidden" name="loan_id" value="<?= htmlspecialchars($loan['id']) ?>">
                                <button class="next-step-btn" type="submit">Proceed</button>
                            </form>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
            <?php 
            $i++;
            endforeach; 
            ?>
        </table>
    </div>
<?php endif; ?>

<?php include '../footer.php'; ?>