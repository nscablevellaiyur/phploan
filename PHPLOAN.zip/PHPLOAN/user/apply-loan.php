<?php
$activePage = 'applyloan';
$onlyHeaderCss = true;
include '../header.php';
?>

<?php

require '../includes/functions.php';

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'user', 'officer'])) {
    die("Access denied.");
}

$loanTypes = read_json('../data/loan_types.json');
$loans = read_json('../data/loans.json');

$username = $_SESSION['username'];
$email = $_SESSION['email'] ?? '';

$message = '';
$selectedLoanTypeName = '';
$selectedLoanTypeInterest = '';
$submittedAmount = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedAmount = $_POST['amount'];
    $selectedLoanTypeName = $_POST['loan_name'] ?? '';
    $selectedLoanTypeInterest = $_POST['loan_interest'] ?? '';
    $selectedDuration = $_POST['duration'] ?? 12;
    $panNumber = $_POST['pan_number'] ?? '';
    $panFront = $_FILES['pan_front'] ?? null;
    $selectedLoanType = null;

    foreach ($loanTypes as $type) {
        if ($type['name'] === $selectedLoanTypeName && floatval($type['interest']) == floatval($selectedLoanTypeInterest)) {
            $selectedLoanType = $type;
            break;
        }
    }

    $amount = floatval($submittedAmount);
    if (!$selectedLoanType) {
        $message = '<div class="error">Invalid loan name and interest combination selected.</div>';
    } elseif ($amount < 1000) {
        $message = '<div class="error">Amount must be at least 1000.</div>';
    } elseif (!preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/', $panNumber)) {
        $message = '<div class="error">Invalid PAN number format.</div>';
    } elseif (!$panFront || $panFront['error'] !== 0) {
        $message = '<div class="error">PAN card front image is required.</div>';
    } else {
        $uploadDir = 'uploads/pan_cards/';
        if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);
        $frontPath = $uploadDir . uniqid('front_') . '_' . basename($panFront['name']);
        move_uploaded_file($panFront['tmp_name'], $frontPath);

        $loans[] = [
            'id' => uniqid(),
            'user_id' => $email,
            'username' => $username,
            'loan_type_id' => $selectedLoanType['id'],
            'loan_type_name' => $selectedLoanType['name'],
            'interest' => $selectedLoanTypeInterest,
            'amount' => $amount,
            'duration' => (int)$selectedDuration,
            'status' => 'pending',
            'submitted_at' => date('Y-m-d H:i:s'),
            'reviewed_by' => null,
            'reviewed_at' => null,
            'pan_number' => $panNumber,
            'pan_front' => $frontPath
        ];

        write_json('../data/loans.json', $loans);

        $message = '
        <div id="successModal" class="modal">
            <div class="modal-content">
                <h3>Application Submitted</h3>
                <p>Your loan application was successfully submitted.</p>
            </div>
        </div>
        <script>
            setTimeout(() => {
                document.getElementById("successModal").style.display = "flex";
            }, 300);

            setTimeout(() => {
                window.location.href = "../dashboard/index.php";
            }, 2000);
        </script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Apply for a Loan</title>
    <style>
        html, body {
            height: 100%;
            
            margin: 0;
            padding: 0;
        }
        

        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #89f7fe, #66a6ff);
            background-size: 400% 400%;
            animation: gradientMove 10s ease infinite;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        form {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.3);
            animation: popIn 1s ease-out;
            width: 90%;
            max-width:100vh;
            max-height:100vh;
            
        }

        @keyframes popIn {
            0% { transform: scale(0.8); opacity: 0; }
            60% { transform: scale(1.05); opacity: 1; }
            100% { transform: scale(1); }
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
            display: block;
            color: #333;
        }

        input, select {
            width: 100%;
            padding:6px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-size: 16px;
        }

        input:focus, select:focus {
            border-color: #007bff;
            box-shadow: 0 0 10px rgba(0, 123, 255, 0.2);
            outline: none;
        }

        button {
            width: 100%;
            padding: 14px;
            margin-top: 20px;
            background: linear-gradient(to right, #007bff, #00c6ff);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        button:hover {
            transform: scale(1.03);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .success, .error {
            margin-top: 15px;
            padding: 12px;
            border-radius: 6px;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border-left: 5px solid #28a745;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 5px solid #dc3545;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 999;
            left: 0; top: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.6);
            justify-content: center;
            align-items: center;
            animation: fadeIn 0.3s ease-in-out;
        }

        .modal-content {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.25);
            text-align: center;
            max-width: 400px;
            width: 90%;
        }

        .modal-content h3 {
            margin: 0 0 10px;
            color: #28a745;
        }

        .modal-content p {
            color: #333;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        
        
         html, body {
  overflow: hidden;
}
    html, body {
  margin: 0;
  padding: 0;
  height: 100%;
  display: flex;
  flex-direction: column;
  font-family: Arial, sans-serif;
  overflow: hidden; /* Disable scroll */
}
    </style>
</head>
<body>


<form method="POST" enctype="multipart/form-data">
    <h2>Loan Application Form</h2>
    <?php if (!empty($message)) echo $message; ?>

    <label for="loan_name">Loan Name:</label>
    <select name="loan_name" id="loan_name" required>
        <option value="">-- Select a Type Of Loan --</option>
        <?php foreach ($loanTypes as $type): ?>
            <option value="<?= htmlspecialchars($type['name']) ?>" <?= $type['name'] === $selectedLoanTypeName ? 'selected' : '' ?>>
                <?= htmlspecialchars($type['name']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="loan_interest">Loan Interest:</label>
    <select name="loan_interest" id="loan_interest" required>
        <option value="">-- Select Interest Rate --</option>
        <?php foreach ($loanTypes as $type): ?>
            <option value="<?= htmlspecialchars($type['interest']) ?>" <?= $type['interest'] == $selectedLoanTypeInterest ? 'selected' : '' ?>>
                <?= htmlspecialchars($type['interest']) ?>%
            </option>
        <?php endforeach; ?>
    </select>

    <label for="duration">Loan Duration (months):</label>
    <select name="duration" id="duration" required>
        <option value="6">6</option>
        <option value="12" selected>12</option>
        <option value="24">24</option>
    </select>

    <label for="amount">Amount:</label>
    <input type="number" name="amount" id="amount" required placeholder="Amount" min="1000" step="1000" value="<?= htmlspecialchars($submittedAmount ?? '') ?>">

    <label for="pan_number">PAN Number:</label>
    <input type="text" name="pan_number" id="pan_number" required pattern="[A-Z]{5}[0-9]{4}[A-Z]{1}" placeholder="ABCDE1234F">

    <label for="pan_front">Upload PAN Card (Front Only):</label>
    <input type="file" name="pan_front" id="pan_front" accept=".jpg,.jpeg,.png,.pdf" required>

    <div id="repayment-estimate" style="margin-top: 15px; display: none;"></div>

    <button type="submit">Apply</button>
</form>

<script>
    const loanData = <?= json_encode($loanTypes); ?>;
    const loanNameSelect = document.getElementById('loan_name');
    const loanInterestSelect = document.getElementById('loan_interest');
    const amountInput = document.getElementById('amount');
    const durationInput = document.getElementById('duration');

    loanNameSelect.addEventListener('change', function () {
        const selectedName = this.value;
        const matched = loanData.find(loan => loan.name === selectedName);
        loanInterestSelect.innerHTML = '<option value="">-- Select Interest Rate --</option>';
        if (matched) {
            const option = document.createElement('option');
            option.value = matched.interest;
            option.textContent = matched.interest + '%';
            option.selected = true;
            loanInterestSelect.appendChild(option);
        }
        updateEstimate();
    });

    [amountInput, loanInterestSelect, durationInput].forEach(input => {
        input.addEventListener('input', updateEstimate);
        input.addEventListener('change', updateEstimate);
    });

    function updateEstimate() {
        const amount = parseFloat(amountInput.value);
        const interest = parseFloat(loanInterestSelect.value);
        const months = parseInt(durationInput.value);

        const estimateBox = document.getElementById('repayment-estimate');

        if (!isNaN(amount) && !isNaN(interest) && !isNaN(months)) {
            const total = amount + (amount * interest / 100);
            const monthly = total / months;
            estimateBox.innerHTML =
                `<strong>Total Repayment:</strong> ₦${total.toFixed(2)}<br>` +
                `<strong>Monthly Payment:</strong> ₦${monthly.toFixed(2)}`;
            estimateBox.style.display = 'block';
        } else {
            estimateBox.style.display = 'none';
        }
    }

    document.querySelector('form').addEventListener('submit', function (e) {
        if (!confirm("Are you sure you want to submit this loan application?")) {
            e.preventDefault();
        }
    });
</script>
</body>
</html>

<?php include '../footer.php'; ?>