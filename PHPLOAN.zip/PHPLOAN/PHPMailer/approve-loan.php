<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

$loans = json_decode(file_get_contents('data/loans.json'), true);
$statusMessage = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loanId = $_POST['loan_id'];

    foreach ($loans as &$loan) {
        if ($loan['id'] == $loanId) {
            $loan['status'] = 'approved';

            $mail = new PHPMailer(true);
            try {
                // SMTP configuration
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'suriyamass9442@gmail.com'; // Your Gmail
                $mail->Password = 'qiuzdeijpixojstu';  // Your Gmail App Password
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('yourname@gmail.com', 'Loan System');
                $mail->addAddress('suriyamass9442@gmail.com');

                $mail->isHTML(true);
                $mail->Subject = 'Loan Approved - ID ' . $loan['id'];
                $mail->Body = "
                    <h2>Loan Approved</h2>
                    <p><strong>User:</strong> {$loan['username']}</p>
                    <p><strong>Loan ID:</strong> {$loan['id']}</p>
                    <p><strong>Amount:</strong> {$loan['amount']}</p>
                ";

                $mail->send();
                $statusMessage = "Loan approved and email sent.";
            } catch (Exception $e) {
                $statusMessage = "Loan approved, but email failed. Error: {$mail->ErrorInfo}";
            }

            file_put_contents('data/loans.json', json_encode($loans, JSON_PRETTY_PRINT));
            break;
        }
    }
}
?>

<h2>Approve Loan</h2>
<form method="POST">
    <label>Loan ID:</label><br>
    <input type="text" name="loan_id" required><br><br>
    <button type="submit">Approve and Send Email</button>
</form>

<?php if ($statusMessage): ?>
    <p><strong><?= $statusMessage ?></strong></p>
<?php endif; ?>