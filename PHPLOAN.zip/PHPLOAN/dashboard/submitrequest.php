<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'name' => htmlspecialchars($_POST['name']),
        'email' => htmlspecialchars($_POST['email']),
        'phone' => htmlspecialchars($_POST['phone']),
        'message' => htmlspecialchars($_POST['message']),
        'timestamp' => date('Y-m-d H:i:s')
    ];

    $file = '../data/requests.json';

    if (!file_exists('data')) {
        mkdir('data', 0777, true);
    }

    $existing = [];
    if (file_exists($file)) {
        $existing = json_decode(file_get_contents($file), true);
    }

    $existing[] = $data;
    file_put_contents($file, json_encode($existing, JSON_PRETTY_PRINT));

    echo "<script>alert('Thank you! Your message has been sent.'); window.location.href = '../home.php';</script>";
}
?>
