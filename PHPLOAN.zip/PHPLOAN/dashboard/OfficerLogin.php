<?php
session_start();

// Redirect if already logged in
if (isset($_SESSION['username']) && $_SESSION['role'] === 'officer') {
    header("Location: officerdashboard.php");
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars(trim($_POST['username']));
    $password = trim($_POST['password']);

    $users = json_decode(file_get_contents('../data/users.json'), true);

    foreach ($users as $user) {
        if ($user['username'] === $username && $user['role'] === 'officer') {
            if (password_verify($password, $user['password'])) {
                $_SESSION['username'] = $username;
                $_SESSION['role'] = 'officer';
                $_SESSION['user_id'] = $user['user_id'];
                header("Location: officerdashboard.php");
                exit();
            } else {
                $error = "Incorrect password.";
            }
        }
    }

    if (!$error) {
        $error = "Officer account not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Officer Login</title>
    <style>
       /* Fade-in animation */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(30px); }
    to { opacity: 1; transform: translateY(0); }
}

body {
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, #4facfe, #00f2fe);
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    margin: 0;
    overflow: hidden;
}

#particles-js {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
}

.login-box {
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
    width: 100%;
    max-width: 370px;
    animation: fadeIn 1s ease-in-out;
    transition: transform 0.3s ease;
}

.login-box:hover {
    transform: scale(1.02);
}

.login-box h2 {
    margin-bottom: 25px;
    color: #333;
    text-align: center;
}

.login-box input[type="text"],
.login-box input[type="password"] {
    width: 100%;
    padding: 12px;
    margin-bottom: 18px;
    border: 1px solid #ccc;
    border-radius: 6px;
    transition: all 0.3s ease;
    font-size: 15px;
}

.login-box input[type="text"]:focus,
.login-box input[type="password"]:focus {
    border-color: #007bff;
    box-shadow: 0 0 8px rgba(0, 123, 255, 0.4);
    outline: none;
    transform: scale(1.02);
}

.login-box button {
    width: 100%;
    padding: 12px;
    background: #007bff;
    color: white;
    border: none;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
    transition: background 0.3s, transform 0.2s;
    font-size: 16px;
}

.login-box button:hover {
    background: #0056b3;
    transform: scale(1.01);
}

.login-box button:active {
    transform: scale(0.98);
}

.error {
    color: red;
    margin-bottom: 15px;
    text-align: center;
    animation: fadeIn 0.5s;
}

    </style>
</head>

<body>
    
    <div id="particles-js"></div>
    <div class="login-box">
        <h2>Officer Login</h2>
        <?php if ($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
    </div>
    <!-- Particles.js -->
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
particlesJS("particles-js", {
  "particles": {
    "number": { "value": 40 },
    "color": { "value": "#007bff" },
    "shape": { "type": "circle" },
    "opacity": { "value": 0.3 },
    "size": { "value": 3 },
    "line_linked": {
      "enable": true,
      "distance": 150,
      "color": "#007bff",
      "opacity": 0.4,
      "width": 1
    },
    "move": { "enable": true, "speed": 10 }
  },
  "interactivity": {
    "events": {
      "onhover": { "enable": true, "mode": "repulse" }
    }
  }
});
</script>
</body>
</html>
