<?php

require '../includes/functions.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/phpmailer/src/Exception.php';
require '../phpmailer/phpmailer/src/PHPMailer.php';
require '../phpmailer/phpmailer/src/SMTP.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'officer') {
    $_SESSION['emailStatusMessage'] = '<p class="status-message error">Access denied.</p>';
    header('Location: officer_dashboard.php');
    exit;
}

$loans = read_json('../data/loans.json');

function sendLoanStatusEmail($email, $username, $loanId, $amount, $status) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'suriyamass9442@gmail.com';
        $mail->Password   = 'qiuzdeijpixojstu';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->setFrom('suriyamass9442@gmail.com', 'Loan System');
        $mail->addAddress($email, $username);
        $mail->isHTML(true);
        $mail->Subject = "Loan {$status} - ID $loanId";
        $mail->Body = "
            <h3>Dear $username,</h3>
            <p>Your loan application has been <strong>$status</strong>.</p>
            <p><strong>Loan ID:</strong> $loanId</p>
            <p><strong>Amount:</strong> $amount</p>
            <p>Thank you for using our loan service.</p>
        ";
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mail error: ' . $mail->ErrorInfo);
        return false;
    }
}

$action = $_POST['action'] ?? '';
$loanId = $_POST['loan_id'] ?? '';

if (!$action || !$loanId) {
    $_SESSION['emailStatusMessage'] = '<p class="status-message error">Missing data.</p>';
    header('Location: officer_dashboard.php');
    exit;
}

foreach ($loans as &$loan) {
    if ($loan['id'] === $loanId) {
        $loan['status'] = $action;
        $loan['reviewed_by'] = $_SESSION['user']['id'];
        $loan['reviewed_at'] = date('Y-m-d H:i:s');

        $email = $loan['user_id'];
        $username = $loan['username'];
        $isSent = sendLoanStatusEmail($email, $username, $loan['id'], $loan['amount'], $action);

        write_json('../data/loans.json', $loans);

        if ($isSent) {
            $_SESSION['emailStatusMessage'] = "<p class='status-message'>Email sent to $username ($email).</p>";
        } else {
            $_SESSION['emailStatusMessage'] = "<p class='status-message error'>Failed to send email to $email.</p>";
        }

        header('Location: officer_dashboard.php');
        exit;
    }
}

$_SESSION['emailStatusMessage'] = '<p class="status-message error">Loan not found.</p>';
header('Location: officer_dashboard.php');
exit;