<?php
session_start();

// Only allow admin and officer roles
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['admin', 'officer'])) {
    die("Access denied. Only Admins and Officers can view this page.");
}

$file = '../data/requests.json';
$requests = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_index']) && $_SESSION['role'] === 'admin') {
    $deleteIndex = (int)$_POST['delete_index'];
    if (file_exists($file)) {
        $requests = json_decode(file_get_contents($file), true);
        if (isset($requests[$deleteIndex])) {
            array_splice($requests, $deleteIndex, 1);
            file_put_contents($file, json_encode($requests, JSON_PRETTY_PRINT));
        }
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

if (file_exists($file)) {
    $requests = json_decode(file_get_contents($file), true);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - Contact Requests</title>
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(to bottom,hsla(249, 86.50%, 40.80%, 0.62),rgb(18, 236, 153));
      animation: fadeIn 1s ease-in;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    table {
      border-collapse: collapse;
      width: 100%;
      margin-top: 30px;
    }
    th, td {
      padding: 10px;
      border: 1px solid #ccc;
      text-align: left;
      animation: slideIn 0.5s ease-in;
    }
    th {
      background: #f5f5f5;
    }
    @keyframes slideIn {
      from { transform: translateY(10px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    button.delete-btn {
      background: red;
      color: white;
      border: none;
      padding: 5px 10px;
      cursor: pointer;
      border-radius: 5px;
    }
    .modal {
      display: none;
      position: fixed;
      z-index: 999;
      padding-top: 100px;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.5);
    }
    .modal-content {
      background-color: #fff;
      margin: auto;
      padding: 20px;
      border: 1px solid #888;
      width: 400px;
      border-radius: 10px;
      animation: zoomIn 0.3s ease-in;
    }
    @keyframes zoomIn {
      from { transform: scale(0.9); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }
    .modal-buttons {
      display: flex;
      justify-content: flex-end;
      margin-top: 20px;
    }
    .modal-buttons button {
      margin-left: 10px;
    }
  </style>
</head>
<body>
  <h2 data-aos="fade-down">Contact Form Submissions</h2>
  <table data-aos="fade-up">
    <tr>
      <th>Name</th><th>Email</th><th>Phone</th><th>Message</th><th>Timestamp</th>
    </tr>
    <?php foreach ($requests as $index => $r): ?>
    <tr>
      <td><?= htmlspecialchars($r['name']) ?></td>
      <td><?= htmlspecialchars($r['email']) ?></td>
      <td><?= htmlspecialchars($r['phone']) ?></td>
      <td><?= nl2br(htmlspecialchars($r['message'])) ?></td>
      <td>
        <?= htmlspecialchars($r['timestamp']) ?>
        <?php if ($_SESSION['role'] === 'admin'): ?>
        <button class="delete-btn" onclick="confirmDelete(<?= $index ?>)">Delete</button>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>

  <div id="deleteModal" class="modal">
    <div class="modal-content">
      <p>Are you sure you want to delete this request?</p>
      <form id="deleteForm" method="POST">
        <input type="hidden" name="delete_index" id="deleteIndex">
        <div class="modal-buttons">
          <button type="button" onclick="closeModal()">Cancel</button>
          <button type="submit" class="delete-btn">Confirm Delete</button>
        </div>
      </form>
    </div>
  </div>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init();

    function confirmDelete(index) {
      document.getElementById('deleteIndex').value = index;
      document.getElementById('deleteModal').style.display = 'block';
    }

    function closeModal() {
      document.getElementById('deleteModal').style.display = 'none';
    }

    window.onclick = function(event) {
      const modal = document.getElementById('deleteModal');
      if (event.target == modal) {
        closeModal();
      }
    }
  </script>
</body>
</html>
