<?php
session_start();

if (
    !isset($_SESSION['role']) || 
    !in_array($_SESSION['role'], ['admin', 'user', 'officer'])
) {
    die("Access denied.");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Officer Management System</title>
    <style>
        /* Animated background */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(-45deg, #74ebd5, #ACB6E5, #fbc2eb, #a6c1ee);
            background-size: 400% 400%;
            animation: moveBackground 15s ease infinite;
            text-align: center;
            padding: 50px;
            margin: 0;
        }

        @keyframes moveBackground {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        h1 {
            color: #fff;
            margin-bottom: 40px;
            animation: slideDown 1s ease-in-out;
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .card {
    display: inline-block;
    width: 300px;
    background: rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(15px);
    -webkit-backdrop-filter: blur(15px);
    margin: 20px;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.3);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    animation: fadeInCard 1s ease-in-out;
}

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
        }

        @keyframes fadeInCard {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .card h2 {
            margin-bottom: 20px;
            color: #333;
        }

        .card a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: background 0.3s ease, transform 0.3s ease;
        }

        .card a:hover {
            background: #0056b3;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <h1>Welcome to the Officer Management System</h1>
    
    <div class="card">
        <h2>View User Request</h2>
        <a href="../dashboard/viewrequest.php">Go</a>
    </div>

    <div class="card">
        <h2>View User Loan</h2>
        <a href="../dashboard/loanapproval.php">Go</a>
    </div>

    <div class="card">
        <h2>View User Payment</h2>
        <a href="../user/payment/verify_payment.php">Go</a>
    </div>

    <div class="card">
        <h2>Exit</h2>
        <a href="../LoginData/Logout.php">Logout</a>
    </div>
</body>
</html>
