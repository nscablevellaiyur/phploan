<?php
$activePage = 'officerdashboard';
$onlyHeaderCss = true;
include '../header.php';


if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'officer') {
    die("Access denied. Officers only.");
}

require '../includes/functions.php';
$loans = read_json('../data/loans.json');
$pendingLoans = array_filter($loans, fn($l) => $l['status'] === 'pending');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Officer Dashboard</title>
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }

        body {
            display: flex;
            flex-direction: column;
            background: linear-gradient(135deg, #74ebd5, #ACB6E5, #fbc2eb, #a18cd1);
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        main.scroll-area {
            flex: 1;
            overflow-y: auto;
            overflow-x: auto;
            padding: 20px;
        }

        h2, h3 {
            opacity: 0;
            background: linear-gradient(90deg, #007bff, #00c6ff, #007bff);
            background-size: 200% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: fadeScale 0.7s ease-out forwards, textShine 3s linear infinite;
            text-align: center;
            margin-top: 20px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        h2 { font-size: 2em; animation-delay: 0s; }
        h3 { font-size: 1.5em; animation-delay: 0.3s; }

        @keyframes fadeScale {
            to { opacity: 1; transform: scale(1); }
        }

        @keyframes textShine {
            0% { background-position: 200% center; }
            100% { background-position: -200% center; }
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            animation: fadeIn 1s ease-in;
        }

        th {
            background-color: #007bff;
            color: white;
            padding: 12px 10px;
            text-align: center;
            font-weight: bold;
            border: 1px solid #ddd;
        }

        td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
            background-color: #fff;
            transition: all 0.3s ease;
        }

        td:hover {
            background-color: #e0f7ff;
            color: #005b96;
        }

        tr {
            opacity: 0;
            transform: translateY(10px);
            animation: slideFade 0.5s ease-out forwards;
            animation-delay: var(--delay);
        }

        @keyframes slideFade {
            to { opacity: 1; transform: translateY(0); }
        }

        .confirm-btn {
            padding: 6px 12px;
            margin: 2px;
            border: none;
            border-radius: 6px;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .confirm-btn.approve {
            background-color: #4CAF50;
        }

        .confirm-btn.approve:hover {
            background-color: #45a049;
            transform: scale(1.05);
        }

        .confirm-btn.reject {
            background-color: #f44336;
        }

        .confirm-btn.reject:hover {
            background-color: #e53935;
            transform: scale(1.05);
        }

        .status-message {
            text-align: center;
            font-weight: bold;
            color: green;
            margin-bottom: 10px;
        }

        .status-message.error { color: red; }

        #pan-display {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: none;
            background: rgba(0,0,0,0.6);
            align-items: center;
            justify-content: center;
            z-index: 998;
        }

        #pan-display.show {
            display: flex;
        }

        #pan-image {
            max-width: 90%;
            max-height: 80%;
            border: 3px solid white;
            border-radius: 12px;
            box-shadow: 0 0 10px #000;
        }

        a.view-pan {
            color: #007bff;
            text-decoration: underline;
            cursor: pointer;
        }

        /* Modal and Spinner */
        #confirmModal {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.6);
            justify-content: center;
            align-items: center;
            z-index: 999;
        }

        .modal-box {
            background: white;
            padding: 30px 20px;
            border-radius: 10px;
            text-align: center;
            max-width: 400px;
            width: 90%;
        }

        #pleaseWaitText {
            display: none;
            margin-top: 15px;
            font-weight: bold;
            color: #007bff;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #007bff;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media only screen and (max-width: 600px) {
            h2 { font-size: 1.5em; }
            h3 { font-size: 1.2em; }
            table { font-size: 0.9em; }
            th, td { padding: 8px; }
            .confirm-btn { font-size: 0.9em; padding: 5px 10px; }
            #pan-image { max-width: 100%; max-height: 300px; }
        }
   

    </style>
</head>
<body>

<h2>Officer Dashboard</h2>


<h3>Pending Loan Applications</h3>
<main class="scroll-area">

<?php if (isset($_SESSION['emailStatusMessage'])): ?>
    <div class="status-message"><?= $_SESSION['emailStatusMessage'] ?></div>
    <?php unset($_SESSION['emailStatusMessage']); ?>
<?php endif; ?>

<table>
    <tr>
        <th>User</th>
        <th>Email</th>
        <th>Type</th>
        <th>Amount</th>
        <th>Submitted</th>
        <th>PAN</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($pendingLoans as $index => $loan): ?>
    <tr style="--delay: <?= 0.1 * $index ?>s;">
        <td><?= htmlspecialchars($loan['username']) ?></td>
        <td><?= htmlspecialchars($loan['user_id']) ?></td>
        <td><?= htmlspecialchars($loan['loan_type_id']) ?></td>
        <td><?= htmlspecialchars($loan['amount']) ?></td>
        <td><?= htmlspecialchars($loan['submitted_at']) ?></td>
        <td>
            <?php if (!empty($loan['pan_front'])): ?>
                <a href="#" class="view-pan" data-image="http://localhost:8080/PHPLOAN/user/<?= htmlspecialchars($loan['pan_front']) ?>">Click to View</a>
            <?php else: ?>
                N/A
            <?php endif; ?>
        </td>
        <td>
            <button class="confirm-btn approve" data-loan="<?= $loan['id'] ?>" data-action="approved">Approve</button>
            <button class="confirm-btn reject" data-loan="<?= $loan['id'] ?>" data-action="rejected">Reject</button>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<!-- PAN Image Viewer -->
<div id="pan-display">
    <img id="pan-image" src="" alt="PAN Image">
</div>

<!-- Confirmation Modal -->
<div id="confirmModal">
    <div class="modal-box">
        <p id="confirmText" style="font-weight:bold; font-size:18px;">Are you sure?</p>
        <form id="confirmForm" method="POST" action="officer.php" onsubmit="showPleaseWait()">
            <input type="hidden" name="loan_id" id="modalLoanId">
            <input type="hidden" name="action" id="modalAction">
            <button type="submit" style="background:#4CAF50; color:white; padding:10px 20px; margin:5px; border:none; border-radius:6px;">Yes</button>
            <button type="button" onclick="closeModal()" style="background:#f44336; color:white; padding:10px 20px; margin:5px; border:none; border-radius:6px;">Cancel</button>
            <div id="pleaseWaitText">
                <div class="spinner"></div>
                Please wait...
            </div>
        </form>
    </div>
</div>

<script>
    // PAN Image Toggle and Outside Click
    const panDisplay = document.getElementById('pan-display');
    const panImage = document.getElementById('pan-image');

    document.querySelectorAll('.view-pan').forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            const imageUrl = this.getAttribute('data-image');

            if (panDisplay.classList.contains('show') && panImage.src === imageUrl) {
                panDisplay.classList.remove('show');
                panImage.src = '';
            } else {
                panImage.src = imageUrl;
                panDisplay.classList.add('show');
            }
        });
    });

    panDisplay.addEventListener('click', function (e) {
        if (e.target === panDisplay) {
            panDisplay.classList.remove('show');
            panImage.src = '';
        }
    });

    // Modal logic
    function closeModal() {
        document.getElementById("confirmModal").style.display = "none";
    }

    function showPleaseWait() {
        document.getElementById('pleaseWaitText').style.display = 'flex';
    }

    document.querySelectorAll(".confirm-btn").forEach(btn => {
        btn.addEventListener("click", function () {
            const loanId = this.getAttribute("data-loan");
            const action = this.getAttribute("data-action");

            document.getElementById("modalLoanId").value = loanId;
            document.getElementById("modalAction").value = action;

            document.getElementById("confirmText").textContent = `Are you sure you want to ${action === 'approved' ? 'approve' : 'reject'} this loan?`;
            document.getElementById("pleaseWaitText").style.display = 'none';

            document.getElementById("confirmModal").style.display = "flex";
        });
    });
</script>

</main>
<?php include '../footer.php'; ?>
</body>
</html>
