<?php
$activePage = 'officerdashboard';
$onlyHeaderCss = true;
include '../header.php';

require '../includes/functions.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Access denied. Officers only.");
}

$users = read_json('../data/users.json');
$loanTypes = read_json('../data/loan_types.json');

// Handle adding a loan type
if (isset($_POST['add_loan'])) {
    $loanTypes[] = [
        'id' => uniqid(),
        'name' => htmlspecialchars(trim($_POST['loan_name'])),
        'interest' => floatval($_POST['interest']),
        'term_months' => intval($_POST['term'])
    ];
    write_json('../data/loan_types.json', $loanTypes);
    $_SESSION['message'] = "Loan type added!";
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Handle adding an officer
if (isset($_POST['add_officer'])) {
    $newOfficer = [
        'user_id' => uniqid("user_"),
        'username' => htmlspecialchars(trim($_POST['officer_username'])),
        'email' => isset($_POST['officer_email']) ? htmlspecialchars(trim($_POST['officer_email'])) : "",
        'password' => password_hash($_POST['officer_password'], PASSWORD_DEFAULT),
        'role' => 'officer',
        'profile_picture' => 'uploads/default-profile.png',
        'last_active' => time()
    ];

    foreach ($users as $u) {
        if ($u['username'] === $newOfficer['username']) {
            die("Username already exists.");
        }
    }

    $users[] = $newOfficer;
    write_json('../data/users.json', $users);
    write_json('../Login/users.json', $users);

    $_SESSION['message'] = "Officer added!";
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Handle delete officer
if (isset($_GET['delete_officer'])) {
    $index = intval($_GET['delete_officer']);
    if (isset($users[$index]) && $users[$index]['role'] === 'officer') {
        array_splice($users, $index, 1);
        write_json('../data/users.json', $users);
        write_json('../Login/users.json', $users);
        $_SESSION['message'] = "Officer deleted!";
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Handle update officer
if (isset($_POST['update_officer'])) {
    $index = intval($_POST['edit_index']);
    if (isset($users[$index]) && $users[$index]['role'] === 'officer') {
        $users[$index]['username'] = htmlspecialchars(trim($_POST['edit_username']));
        if (!empty($_POST['edit_password'])) {
            $users[$index]['password'] = password_hash($_POST['edit_password'], PASSWORD_DEFAULT);
        }
        if (isset($_POST['edit_email'])) {
            $users[$index]['email'] = htmlspecialchars(trim($_POST['edit_email']));
        }
        write_json('../data/users.json', $users);
        write_json('../Login/users.json', $users);
        $_SESSION['message'] = "Officer updated!";
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/feather-icons"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
        }

        #particles-js {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }

        .container {
            width: 80%;
            margin: auto;
            padding-top: 30px;
        }

        .message {
            background: #e0ffe0;
            padding: 10px;
            border: 1px solid #b2d8b2;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .form-section {
            background: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        input, button {
            padding: 10px;
            margin: 10px 0;
            width: 100%;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #f4f4f4;
        }

        .edit-btn {
            background-color: #2196F3;
            color: #fff;
        }

        .delete-btn {
            background-color: #f44336;
            color: #fff;
        }

        #editModal, #modalOverlay {
            display: none;
        }

        #editModal {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 20px;
            z-index: 1000;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }

        #modalOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }
    </style>
</head>
<body>
<br><br>
<div id="particles-js"></div>

<div class="container">
    <?php if (isset($_SESSION['message'])): ?>
        <p class="message"><?= $_SESSION['message'] ?></p>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

      <div class="form-section fade-in">
        <h3><i data-feather="shield"></i> Admin Only Section</h3>
        <p>Welcome, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>. You have administrative privileges.</p>
    </div>

    <div class="form-section">
        <h3><i data-feather="layers"></i> Add Loan Type</h3>
        <form method="POST">
            <input name="loan_name" required placeholder="Loan Name">
            <input name="interest" type="number" step="0.01" required placeholder="Interest Rate (%)">
            <input name="term" type="number" required placeholder="Term (months)">
            <button name="add_loan">Add Loan Type</button>
        </form>
    </div>

    <div class="form-section">
        <h3><i data-feather="user-plus"></i> Add Officer</h3>
        <form method="POST">
            <input name="officer_username" required placeholder="Username">
            <input name="officer_email" type="email" placeholder="Email (optional)">
            <input name="officer_password" type="password" required placeholder="Password">
            <button name="add_officer">Add Officer</button>
        </form>
    </div>

    <div class="form-section">
        <h3><i data-feather="file-text"></i> Existing Loan Types</h3>
        <ul>
            <?php foreach ($loanTypes as $loan): ?>
                <li><?= htmlspecialchars($loan['name']) ?> - <?= $loan['interest'] ?>% for <?= $loan['term_months'] ?> months</li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="form-section">
        <h3><i data-feather="users"></i> Manage Officers</h3>
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $index => $u): ?>
                    <?php if ($u['role'] === 'officer'): ?>
                        <tr>
                            <td><?= htmlspecialchars($u['username']) ?></td>
                            <td><?= htmlspecialchars($u['email'] ?? '-') ?></td>
                            <td>
                                <button class="edit-btn" onclick="openEditModal(<?= $index ?>, '<?= htmlspecialchars($u['username']) ?>', '<?= htmlspecialchars($u['email'] ?? '') ?>')">Edit</button>
                                <button class="delete-btn" onclick="confirmDelete(<?= $index ?>)">Delete</button>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Edit Modal -->
<div id="modalOverlay" onclick="closeEditModal()"></div>
<div id="editModal">
    <h3>Edit Officer</h3>
    <form method="POST">
        <input type="hidden" name="edit_index" id="edit_index">
        <input name="edit_username" id="edit_username" placeholder="New Username" required><br>
        <input name="edit_email" id="edit_email" type="email" placeholder="Email (optional)"><br>
        <input name="edit_password" type="password" placeholder="New Password (leave blank to keep unchanged)"><br>
        <button type="submit" name="update_officer">Update</button>
        <button type="button" onclick="closeEditModal()">Cancel</button>
    </form>
</div>

<script>
    feather.replace();

    function openEditModal(index, username, email = '') {
        document.getElementById("edit_index").value = index;
        document.getElementById("edit_username").value = username;
        document.getElementById("edit_email").value = email;
        document.getElementById("editModal").style.display = "block";
        document.getElementById("modalOverlay").style.display = "block";
    }

    function closeEditModal() {
        document.getElementById("editModal").style.display = "none";
        document.getElementById("modalOverlay").style.display = "none";
    }

    function confirmDelete(index) {
        if (confirm("Are you sure you want to delete this officer?")) {
            window.location.href = "?delete_officer=" + index;
        }
    }
</script>

<!-- Particles.js -->
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
particlesJS("particles-js", {
  "particles": {
    "number": { "value": 40 },
    "color": { "value": "#007bff" },
    "shape": { "type": "circle" },
    "opacity": { "value": 0.3 },
    "size": { "value": 3 },
    "line_linked": {
      "enable": true,
      "distance": 150,
      "color": "#007bff",
      "opacity": 0.4,
      "width": 1
    },
    "move": { "enable": true, "speed": 2 }
  },
  "interactivity": {
    "events": {
      "onhover": { "enable": true, "mode": "repulse" }
    }
  }
});
</script>
</body>
</html>

<?php include '../footer.php'; ?>
