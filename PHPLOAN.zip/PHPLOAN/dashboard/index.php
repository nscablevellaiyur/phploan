<?php


$activePage = 'officerdashboard';
$onlyHeaderCss = true;
include '../header.php';

// Role check
if (
    !isset($_SESSION['role']) || 
    !in_array($_SESSION['role'], ['admin', 'user'])
) {
    header("Location: ../Login/login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'unknown_user';
$emiFile = "../user/Payment/data/payments/$username.json";
$emiExists = file_exists($emiFile);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        html, body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow: hidden;
        }

        main {
            margin-top: 70px;
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }

        body {
            background: linear-gradient(to right, #4facfe, #00f2fe);
        }

        .container {
            text-align: center;
            min-width: 1000px;
            width: 100%;
            margin: 0 auto;
            animation: fadeIn 3s ease-in-out;
        }

        h1 {
            color: white;
            font-size: 5.5rem;
            margin-bottom: 30px;
            font-weight: 600;
        }

        .card {
            background: skyblue;
            padding: 20px 15px;
            margin-bottom: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card i {
            font-size: 1.8rem;
            color: #007bff;
            margin-bottom: 10px;
            transition: transform 0.3s ease;
        }

        .card:hover i {
            transform: scale(1.1) rotate(5deg);
        }

        .card h2 {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
        }

        .card a, .card button {
            display: inline-block;
            margin-top: 8px;
            padding: 8px 18px;
            background: #007bff;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .card a:hover, .card button:hover {
            background: #0056b3;
            transform: scale(1.05);
        }

        #emiMessage {
            margin-top: 10px;
            font-weight: bold;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h3 {
            display: inline-block;
            font-size: 25px;
            font-weight: bold;
            background-image: url('text.gif'); 
            background-size: 100% 100%;
            color: transparent;
            -webkit-background-clip: text;
            background-clip: text;
            margin-top:-150px;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>
<main>
    <div class="container">
    <br>
    <br>
    <br>
        <h3>Welcome to the User Management System</h3>

        <div class="card">
            <i class="fas fa-file-alt"></i>
            <h2>Apply for a Loan</h2>
            <a href="../user/apply-loan.php">Apply</a>
        </div>

        <div class="card">
            <i class="fas fa-list-check"></i>
            <h2>My Loan Status</h2>
            <a href="../user/loan-status.php">View Status</a>
        </div>

        <h2 style="color:white; margin-top: 40px; margin-bottom: 20px;">EMI Management</h2>

        <div class="card">
            <i class="fas fa-calendar-alt"></i>
            <h2>EMI Schedule</h2>
            <?php if ($emiExists): ?>
                <button onclick="window.location.href = '../user/Payment/EmiSchedule.php';">View EMI Schedule</button>
            <?php else: ?>
                <button id="generateEmiBtn">Generate EMI Schedule</button>
                <div id="emiMessage"></div>
            <?php endif; ?>
        </div>

        <div class="card">
            <i class="fas fa-credit-card"></i>
            <h2>Pay Single EMI</h2>
            <a href="../user/Payment/PaySingle.php">Pay Now</a>
        </div>

        <div class="card">
            <i class="fas fa-credit-card"></i>
            <h2>Pay Multiple EMI</h2>
            <a href="../user/Payment/PayFullMonth.php">Pay Now</a>
        </div>
    </div>
</main>

<script>
    const generateBtn = document.getElementById("generateEmiBtn");
    if (generateBtn) {
        generateBtn.addEventListener("click", function () {
            fetch("../user/Payment/Emigenerator.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: "generateAjax=1"
            })
            .then(response => response.json())
            .then(data => {
                const msg = document.getElementById("emiMessage");
                msg.innerText = data.message;
                msg.style.color = (data.status === "success") ? "lime" : (data.status === "warning") ? "orange" : "red";

                if (data.status === "success") {
                    generateBtn.innerText = "View EMI Schedule";
                    generateBtn.setAttribute("onclick", "window.location.href = '../user/Payment/EmiSchedule.php';");
                    generateBtn.removeEventListener("click", arguments.callee);
                }
            })
            .catch(() => {
                alert("Error generating EMI schedule.");
            });
        });
    }
</script>
</body>
<br>
<br>
<br>
<br>
<?php include '../footer.php'; ?>
</html>