// fiveserver.config.js
module.exports = {
  php: "D:\\xammp\\php\\php.exe"
};
