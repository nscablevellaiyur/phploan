<?php
session_start(); // Ensure session is started

$styleType = isset($onlyHeaderCss) ? 'header-only' : 'full';
$currentPage = isset($activePage) ? $activePage : '';

// Set home URL based on user role
if (isset($_SESSION['role'])) {
    switch ($_SESSION['role']) {
        case 'user':
            $homeURL = 'http://localhost:8080/PHPLOAN/dashboard/index.php';
            break;
        case 'admin':
            $homeURL = 'http://localhost:8080/PHPLOAN/dashboard/admin.php';
            break;
        case 'officer':
            $homeURL = 'http://localhost:8080/PHPLOAN/dashboard/officerdashboard.php';
            break;
        default:
            $homeURL = '../home.php';
    }
} else {
    $homeURL = '../home.php'; // Default for guest
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Loan System</title>

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

  <style>
    html, body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', sans-serif;
      background: ;
    }

    header {
      position: fixed;
      top: 0;
      width: 100%;
      background: rgba(0, 64, 128, 0.8);
      backdrop-filter: blur(10px);
      color: white;
      padding: 1rem 2rem;
      z-index: 1000;
      box-shadow: 0 2px 12px rgba(0,0,0,0.2);
    }

    .header-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .logo-text {
      font-size: 1.6rem;
      font-weight: 700;
      margin: 0;
      letter-spacing: 1px;
      margin-left: 4rem;
    }

    .menu-toggle:hover {
      transform: rotate(180deg);
    }

    .menu-toggle.rotate {
      transform: rotate(360deg);
    }

    #navMenu {
      position: fixed;
      top: 70px;
      right: -100%;
      background-color: #004080;
      width: 200px;
      height: calc(100% - 70px);
      transition: right 0.6s ease;
      list-style: none;
      padding-top: 100px;
      margin: 0;
      z-index: 1000;
    }

    #navMenu.show {
      right: 0;
    }

    #navMenu li {
      margin: 1rem 0;
      opacity: 0;
      transform: translateX(30px);
      animation: fadeInRight 0.4s forwards;
    }

    #navMenu.show li {
      opacity: 1;
    }

    #navMenu.show li:nth-child(1) { animation-delay: 0.1s; }
    #navMenu.show li:nth-child(2) { animation-delay: 0.2s; }
    #navMenu.show li:nth-child(3) { animation-delay: 0.3s; }
    #navMenu.show li:nth-child(4) { animation-delay: 0.4s; }
    #navMenu.show li:nth-child(5) { animation-delay: 0.5s; }
    #navMenu.show li:nth-child(6) { animation-delay: 0.6s; }

    @keyframes fadeInRight {
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    #navMenu a {
      color: white;
      text-decoration: none;
      font-size: 1.1rem;
      padding: 0.8rem 1.2rem;
      display: flex;
      align-items: center;
      border-radius: 12px;
      margin: 0 1rem;
      transition: background 0.3s;
    }

    #navMenu a:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }

    #navMenu a i {
      margin-right: 12px;
      font-size: 18px;
      width: 24px;
      text-align: center;
    }

    <?php if ($styleType === 'full'): ?>
    main {
      margin-top: 90px;
      padding: 2rem;
    }
    <?php endif; ?>

    <?php
    $toggleMarginRight = [
      'applyloan' => '1rem',
      'loanstatus' => '3rem',
      'login' => '1rem',
      'finalconfirm' => '4rem',
      'emischedule' => '4rem',
      'officerdashboard' => '3rem',
      'register' => '3rem',
    ];

    if (array_key_exists($currentPage, $toggleMarginRight)) {
        echo ".menu-toggle {
          background: transparent;
          border: none;
          font-size: 28px;
          color: white;
          cursor: pointer;
          transition: transform 0.3s;
          margin-right: {$toggleMarginRight[$currentPage]};
        }";
    }
    ?>
  </style>
</head>
<body>

<header>
  <div class="header-container">
    <h1 class="logo-text">Loan System</h1>
    <div class="menu-toggle" onclick="toggleMenu()"><i class="fas fa-bars"></i></div>
  </div>
</header>

<ul id="navMenu">
  <li><a href="<?php echo $homeURL; ?>"><i class="fas fa-home"></i> Home</a></li>
  <li><a href="http://localhost:8080/PHPLOAN/Login/login.php"><i class="fas fa-user"></i> User Login</a></li>
  <li><a href="http://localhost:8080/PHPLOAN/Login/signup.php"><i class="fas fa-user-plus"></i> Register</a></li>
  <li><a href="http://localhost:8080/PHPLOAN/dashboard/officerlogin.php"><i class="fas fa-user-shield"></i> Officer Login</a></li>
  <li><a href="http://localhost:8080/PHPLOAN/LoginData/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
  <li><a href="http://localhost:8080/PHPLOAN/home.php#contact"><i class="fas fa-envelope"></i> Contact</a></li>
</ul>

<script>
  function toggleMenu() {
    const menu = document.getElementById('navMenu');
    const toggleButton = document.querySelector('.menu-toggle');
    menu.classList.toggle('show');
    toggleButton.classList.toggle('rotate');
  }

  document.querySelectorAll('#navMenu a').forEach(link => {
    link.addEventListener('click', () => {
      document.getElementById('navMenu').classList.remove('show');
      document.querySelector('.menu-toggle').classList.remove('rotate');
    });
  });
</script>

<?php if ($styleType === 'full'): ?>
<main>
<?php endif; ?>
