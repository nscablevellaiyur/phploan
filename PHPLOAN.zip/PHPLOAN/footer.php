<?php
$styleType = isset($onlyHeaderCss) ? 'header-only' : 'full';
?>

<?php if ($styleType === 'full'): ?>
</main>
<?php endif; ?>

<footer style="
  background-color: #004080;
  color: white;
  text-align: center;
  padding: 1rem;
  <?php echo ($styleType === 'full') ? 'position: fixed; bottom: 50px; width: 100%;' : ''; ?>
">
<style>



html, body {
  margin: 0;
  padding: 0;
  height: 100%;
  display: flex;
  flex-direction: column;
  font-family: Arial, sans-serif;
  
}


/* Footer */
footer {
  background: #003366;
  color: white;
  text-align: center;
  position: fixed;
  bottom: 0;
  width: 100%;
  padding: 20px;
  height: 20px;
  z-index: 1000;
}

footer a {
  color: #00aced;
  text-decoration: none;
}

/* Footer link hover effect */
footer a:hover {
  text-decoration: underline;
}


</style>

  &copy; <?php echo date('Y'); ?> Loan Management System
</footer>

</body>
</html>