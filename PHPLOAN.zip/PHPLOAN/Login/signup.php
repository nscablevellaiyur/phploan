<?php
$activePage = 'login';
$onlyHeaderCss = true;
include '../header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Signup</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg, #1e3c72, #2a5298);
      text-align: center;
      color: white;
      height: 100vh;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
    }

    .container {
      width: 50%;
      background: rgba(255, 255, 255, 0.1);
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
      display: flex;
      flex-direction: column;
      align-items: center;
      position: relative;
      overflow: hidden;
      animation: moveBorder 4s infinite;
    }

    @keyframes moveBorder {
      0% {
        border-top: 5px solid #ffcc00;
        border-right: 5px solid #00ccff;
        border-bottom: 5px solid #ff9900;
        border-left: 5px solid #00ff00;
      }
      25% {
        border-top: 5px solid #ff9900;
        border-right: 5px solid #ffcc00;
        border-bottom: 5px solid #00ccff;
        border-left: 5px solid #00ff00;
      }
      50% {
        border-top: 5px solid #00ccff;
        border-right: 5px solid #ff9900;
        border-bottom: 5px solid #00ff00;
        border-left: 5px solid #ffcc00;
      }
      75% {
        border-top: 5px solid #00ff00;
        border-right: 5px solid #00ccff;
        border-bottom: 5px solid #ffcc00;
        border-left: 5px solid #ff9900;
      }
      100% {
        border-top: 5px solid #ffcc00;
        border-right: 5px solid #00ccff;
        border-bottom: 5px solid #ff9900;
        border-left: 5px solid #00ff00;
      }
    }

    .container img {
      width: 100px;
      margin-bottom: 20px;
    }

    input, select {
      width: 90%;
      padding: 10px;
      margin: 10px 0;
      border: none;
      border-radius: 5px;
      text-align: center;
      transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }

    input:focus, select:focus {
      transform: scale(1.05);
      box-shadow: 0 0 15px rgba(0, 255, 255, 0.8);
      outline: none;
    }

    input[type="file"] {
      background: rgba(255, 255, 255, 0.2);
      color: white;
      cursor: pointer;
    }

    input[type="file"]::-webkit-file-upload-button {
      background: #00c6ff;
      border: none;
      padding: 8px 15px;
      border-radius: 5px;
      color: white;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    input[type="file"]::-webkit-file-upload-button:hover {
      background: #008ecc;
    }

    select {
      background: rgba(255, 255, 255, 0.2);
      color: black;
      font-size: 1rem;
      appearance: none;
      -webkit-appearance: none;
      -moz-appearance: none;
    }

    .btn {
      background: #ffcc00;
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.3s, transform 0.2s ease-in-out;
    }

    .btn:hover {
      background: #ff9900;
      transform: scale(1.05);
    }

    .message {
      display: none;
      padding: 15px;
      margin-top: 10px;
      border-radius: 5px;
      text-align: center;
    }

    .error {
      background: rgba(255, 0, 0, 0.8);
      color: white;
      animation: fadeIn 0.5s ease-in-out;
    }

    .success {
      background: rgba(0, 255, 0, 0.8);
      color: white;
      animation: bounceIn 0.5s ease-in-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes bounceIn {
      0% { transform: scale(0.5); opacity: 0; }
      50% { transform: scale(1.1); opacity: 1; }
      100% { transform: scale(1); }
    }

    #preview {
      margin: 10px 0;
      border-radius: 50%;
      width: 80px;
      height: 80px;
      object-fit: cover;
      display: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Signup</h2>
    <form id="signup-form" enctype="multipart/form-data">
      <input type="text" name="username" placeholder="Username" required /><br>
      <input type="email" name="email" placeholder="Email" required /><br>
      <input type="password" name="password" placeholder="Password" required /><br>
      <input type="password" name="confirm_password" placeholder="Confirm Password" required /><br>

      <input type="file" name="profile_picture" accept="image/*" id="profilePic"/><br>
      <img id="preview" />

      <select name="role" required>
        <option value="" disabled selected>Select Role</option>
        <option value="user">User</option>
        <option value="officer">Officer</option>
        <option value="admin">Admin</option>
      </select><br><br>

      <button type="submit" class="btn">Register</button>
    </form>

    <div id="message" class="message"></div>
  </div>

  <script>
    // Form submission
    document.getElementById("signup-form").addEventListener("submit", function(event) {
      event.preventDefault();
      const form = event.target;
      const formData = new FormData(form);
      const messageDiv = document.getElementById("message");

      messageDiv.className = "message";
      messageDiv.innerText = "Please wait...";
      messageDiv.style.display = "block";

      fetch("../LoginData/signup.php", {
        method: "POST",
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          messageDiv.innerHTML = data.error;
          messageDiv.className = "message error";
        } else {
          messageDiv.innerHTML = data.success;
          messageDiv.className = "message success";
          form.reset();
          document.getElementById("preview").style.display = "none";
          setTimeout(() => {
            window.location.href = "../index.php";
          }, 1500);
        }
        messageDiv.style.display = "block";
      })
      .catch(() => {
        messageDiv.innerHTML = "Something went wrong!";
        messageDiv.className = "message error";
        messageDiv.style.display = "block";
      });
    });

    // Profile picture preview
    document.getElementById("profilePic").addEventListener("change", function () {
      const preview = document.getElementById("preview");
      const file = this.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
          preview.src = e.target.result;
          preview.style.display = "block";
        };
        reader.readAsDataURL(file);
      }
    });
  </script>
</body>
</html>
<?php include '../footer.php'; ?>
